package com.pocketflip.overlay

import android.animation.ValueAnimator
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * PnL card studio for one finished trade.
 * Opens from the trade detail page. It only READS the trade; it never touches prices, balance or journal data.
 */
class CardActivity : Activity() {

    companion object {
        const val EXTRA_TRADE_ID = "trade_id"
        private const val REQ_PICK_IMAGE = 7301
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var trade: ClosedTradeLog
    private lateinit var opts: CardOptions
    private lateinit var preview: ImageView
    private var coinBmp: Bitmap? = null
    private var bgBmp: Bitmap? = null
    private var emblemBmp: Bitmap? = null
    private var anim: ValueAnimator? = null
    private var progress = 1f
    private var renderPending = false
    private var lastSavedUri: Uri? = null

    // ---------- helpers ----------
    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vstack() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun hstack() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun LinearLayout.add(
        v: View, top: Int = 0, bottom: Int = 0, left: Int = 0, right: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT, weight: Float = 0f
    ) {
        val p = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        p.topMargin = top; p.bottomMargin = bottom; p.leftMargin = left; p.rightMargin = right
        addView(v, p)
    }

    private fun filledBtn(label: String, onClick: () -> Unit) =
        tv(label, 14f, Theme.onColor(Theme.text), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Theme.box(Theme.text, Theme.text, dp(14), 0)
            setOnClickListener { onClick() }
        }

    private fun outlineBtn(label: String, color: Int = Theme.text, onClick: () -> Unit) =
        tv(label, 13f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
            setOnClickListener { onClick() }
        }

    private fun label(text: String) =
        tv(text, 11f, Theme.muted, bold = true).apply { setPadding(dp(2), dp(14), 0, dp(6)) }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TradeRepository.init(this)
        Theme.init(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg

        val id = intent.getStringExtra(EXTRA_TRADE_ID) ?: ""
        val found = TradeRepository.getJournal().firstOrNull { it.id == id }
        if (found == null) {
            Toast.makeText(this, "Trade not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        trade = found
        opts = CardOptions.open(this)
        // First time only: start from the app theme colors so the card matches the app.
        val prefs = getSharedPreferences(CardOptions.PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("bgHex")) {
            opts.bgHex = Theme.hexOf("bg")
            opts.textHex = Theme.hexOf("text")
            opts.profitHex = Theme.hexOf("profit")
            opts.lossHex = Theme.hexOf("loss")
        }
        emblemBmp = try { BitmapFactory.decodeResource(resources, R.drawable.emblem) } catch (_: Throwable) { null }

        val root = vstack().apply { setBackgroundColor(Theme.bg) }

        // top bar
        val bar = hstack().apply { setPadding(dp(14), dp(12), dp(14), dp(8)) }
        bar.add(outlineBtn("←  Back") { finish() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        bar.add(
            tv("Create card", 17f, Theme.text, bold = true).apply { gravity = Gravity.CENTER },
            w = 0, weight = 1f
        )
        bar.add(outlineBtn("Replay") { replay() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        root.addView(bar)

        // live preview (stays pinned while you scroll the controls)
        val previewBox = FrameLayout(this).apply { setPadding(dp(14), dp(4), dp(14), dp(8)) }
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        previewBox.addView(
            preview,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        root.add(previewBox, h = 0, weight = 5f)

        // controls
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            background = Theme.box(Theme.card, Theme.border, dp(22), dp(1))
        }
        val controls = vstack().apply { setPadding(dp(16), dp(6), dp(16), dp(30)) }
        buildControls(controls)
        scroll.addView(controls)
        root.add(scroll, h = 0, weight = 5f)

        setContentView(root)

        DexScreenerClient.loadTokenBitmap(trade.imageUrl) { bmp ->
            coinBmp = bmp
            main.post { requestRender() }
        }
        requestRender()
    }

    override fun onDestroy() {
        anim?.cancel()
        io.shutdown()
        super.onDestroy()
    }

    // ---------- rendering ----------
    private fun requestRender() {
        if (renderPending) return
        renderPending = true
        main.postDelayed({
            renderPending = false
            renderPreview()
        }, 40)
    }

    private fun renderPreview() {
        if (!::preview.isInitialized) return
        try {
            val bmp = CardRenderer.render(trade, opts, coinBmp, bgBmp, emblemBmp, 560, progress)
            preview.setImageBitmap(bmp)
        } catch (t: Throwable) {
            Toast.makeText(this, "Preview error: ${t.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun changed() {
        opts.save(getSharedPreferences(CardOptions.PREFS, Context.MODE_PRIVATE))
        requestRender()
    }

    private fun replay() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            interpolator = LinearInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                renderPreview()
            }
            start()
        }
    }

    // ---------- controls ----------
    private fun chips(
        parent: LinearLayout, title: String, options: List<Pair<String, String>>,
        current: () -> String, onPick: (String) -> Unit
    ) {
        parent.add(label(title))
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = hstack()
        val views = ArrayList<Pair<String, TextView>>()
        fun paint() {
            for ((key, v) in views) {
                val on = key == current()
                v.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
                v.background = if (on) Theme.box(Theme.text, Theme.text, dp(18), 0)
                else Theme.box(Theme.bg, Theme.border, dp(18), dp(1))
            }
        }
        for ((key, text) in options) {
            val v = tv(text, 12f, Theme.text, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(9), dp(14), dp(9))
                setOnClickListener {
                    onPick(key)
                    paint()
                    changed()
                }
            }
            views.add(key to v)
            row.add(v, right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        paint()
        scroller.addView(row)
        parent.add(scroller)
    }

    private fun toggle(parent: LinearLayout, title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val row = hstack().apply { setPadding(0, dp(7), 0, dp(7)) }
        row.add(tv(title, 13f, Theme.text), w = 0, weight = 1f)
        val sw = tv("", 12f, Theme.text, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        fun paint() {
            val on = get()
            sw.text = if (on) "ON" else "OFF"
            sw.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.muted)
            sw.background = if (on) Theme.box(Theme.text, Theme.text, dp(14), 0)
            else Theme.box(Theme.bg, Theme.border, dp(14), dp(1))
        }
        paint()
        sw.setOnClickListener {
            set(!get())
            paint()
            changed()
        }
        row.add(sw, w = dp(64))
        parent.add(row)
    }

    private fun textInput(parent: LinearLayout, title: String, initial: String, onText: (String) -> Unit) {
        parent.add(label(title))
        val et = EditText(this).apply {
            setText(initial)
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    onText(s?.toString() ?: "")
                    changed()
                }
            })
        }
        parent.add(et)
    }

    private fun hexRow(
        parent: LinearLayout, title: String, get: () -> String, set: (String) -> Unit,
        registry: MutableMap<String, EditText>
    ) {
        val row = hstack().apply { setPadding(0, dp(4), 0, dp(4)) }
        row.add(tv(title, 13f, Theme.text), w = 0, weight = 1f)
        val swatch = View(this).apply {
            background = Theme.box(Theme.parseHex(get()) ?: Color.GRAY, Theme.muted, dp(8), dp(1))
        }
        row.add(swatch, w = dp(30), h = dp(30), right = dp(10))
        val et = EditText(this).apply {
            setText(get())
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = Theme.box(Theme.bg, Theme.border, dp(10), dp(1))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val raw = s?.toString() ?: ""
                    val parsed = Theme.parseHex(raw)
                    if (parsed != null) {
                        swatch.background = Theme.box(parsed, Theme.muted, dp(8), dp(1))
                        set(if (raw.trim().startsWith("#")) raw.trim() else "#" + raw.trim())
                        changed()
                    }
                }
            })
        }
        row.add(et, w = dp(112))
        registry[title] = et
        parent.add(row)
    }

    private fun buildControls(p: LinearLayout) {
        chips(p, "SIZE", listOf("1:1" to "Square 1:1", "4:5" to "Post 4:5", "9:16" to "Story 9:16"),
            { opts.aspect }) { opts.aspect = it }

        chips(p, "BACKGROUND",
            listOf("chrome" to "Chrome glow", "black" to "Solid", "coin" to "Coin blur", "image" to "My image"),
            { opts.bgStyle }) {
            opts.bgStyle = it
            if (it == "image" && bgBmp == null) pickImage()
        }
        p.add(label("BACKGROUND DARKNESS (image / coin)"))
        val seek = SeekBar(this).apply {
            max = 95
            progress = opts.darkness
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) { opts.darkness = v; changed() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        p.add(seek)
        p.add(outlineBtn("Choose background image from gallery") { pickImage() }, top = dp(8))

        chips(p, "BIG NUMBER", listOf("sol" to "SOL PnL", "pct" to "% ROI", "multiple" to "Multiple (x)"),
            { opts.heroMode }) { opts.heroMode = it }
        chips(p, "NUMBER STYLE",
            listOf("chrome" to "Chrome", "clean" to "Clean", "gold" to "Gold", "green" to "Green"),
            { opts.shader }) { opts.shader = it }

        chips(p, "CHART", listOf("real" to "My real fills", "stylized" to "Stylized path"),
            { opts.chartMode }) { opts.chartMode = it }
        p.add(
            tv("Real fills = exactly your buys and sells. Stylized = a decorative curve that starts at your entry, touches your peak and ends at your exit.", 10f, Theme.muted),
            top = dp(4)
        )
        chips(p, "BUY / SELL MARKERS", listOf("pill" to "Labels", "dot" to "Dots", "none" to "None"),
            { opts.markerStyle }) { opts.markerStyle = it }

        p.add(label("SHOW"))
        toggle(p, "Coin picture + ticker", { opts.showCoin }) { opts.showCoin = it }
        toggle(p, "Chart", { opts.showChart }) { opts.showChart = it }
        toggle(p, "Stats (invested, MC, held)", { opts.showStats }) { opts.showStats = it }
        toggle(p, "Contract address", { opts.showCa }) { opts.showCa = it }
        toggle(p, "Branding (logo + name)", { opts.showBrand }) { opts.showBrand = it }
        toggle(p, "\"PAPER TRADE\" tag", { opts.showPaperTag }) { opts.showPaperTag = it }
        toggle(p, "Film grain", { opts.showGrain }) { opts.showGrain = it }
        toggle(p, "Vignette", { opts.showVignette }) { opts.showVignette = it }
        toggle(p, "Frame", { opts.showFrame }) { opts.showFrame = it }

        textInput(p, "NAME ON CARD", opts.displayName) { opts.displayName = it }
        textInput(p, "HANDLE (optional, e.g. @yourname)", opts.handle) { opts.handle = it }

        p.add(label("COLORS"))
        val reg = LinkedHashMap<String, EditText>()
        hexRow(p, "Background", { opts.bgHex }, { opts.bgHex = it }, reg)
        hexRow(p, "Text", { opts.textHex }, { opts.textHex = it }, reg)
        hexRow(p, "Accent / chart line", { opts.accentHex }, { opts.accentHex = it }, reg)
        hexRow(p, "Profit", { opts.profitHex }, { opts.profitHex = it }, reg)
        hexRow(p, "Loss", { opts.lossHex }, { opts.lossHex = it }, reg)

        fun applyColors(bg: String, text: String, accent: String, profit: String, loss: String) {
            reg["Background"]?.setText(bg)
            reg["Text"]?.setText(text)
            reg["Accent / chart line"]?.setText(accent)
            reg["Profit"]?.setText(profit)
            reg["Loss"]?.setText(loss)
        }
        p.add(label("COLOR PRESETS"))
        val presetRow = hstack()
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val presets = listOf(
            "Chrome 73" to listOf("#000000", "#E6E8EB", "#C9CDD3", "#E6E8EB", "#8B8F96"),
            "Chrome + G/R" to listOf("#000000", "#E6E8EB", "#C9CDD3", "#22C55E", "#EF4444"),
            "Pure B&W" to listOf("#000000", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#9A9A9A"),
            "Gold" to listOf("#0A0804", "#F5E6B8", "#E8B923", "#F7D154", "#9A7B2F"),
            "Matrix" to listOf("#02080A", "#D6FFE9", "#22C55E", "#22C55E", "#EF4444")
        )
        for ((name, c) in presets) {
            presetRow.add(
                outlineBtn(name) { applyColors(c[0], c[1], c[2], c[3], c[4]) },
                right = dp(8), w = LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        scroller.addView(presetRow)
        p.add(scroller)

        p.add(filledBtn("Save to gallery") { saveCard(share = false) }, top = dp(22), bottom = dp(8))
        p.add(outlineBtn("Share…") { saveCard(share = true) })
    }

    // ---------- background image ----------
    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "Choose background"), REQ_PICK_IMAGE)
        } catch (_: Throwable) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_IMAGE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        io.execute {
            val bmp = decodeScaled(uri, 1600)
            main.post {
                if (bmp == null) {
                    Toast.makeText(this, "Couldn't open that image", Toast.LENGTH_SHORT).show()
                } else {
                    bgBmp = bmp
                    opts.bgStyle = "image"
                    changed()
                }
            }
        }
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2
            val real = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, real) }
        } catch (_: Throwable) {
            null
        }
    }

    // ---------- export ----------
    private fun saveCard(share: Boolean) {
        Toast.makeText(this, "Rendering card…", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                val full = CardRenderer.render(trade, opts, coinBmp, bgBmp, emblemBmp, 1080, 1f)
                val name = "73MCT_${trade.symbol.trimStart('$')}_${System.currentTimeMillis()}.png"
                val uri = writePng(full, name)
                main.post {
                    if (uri == null) {
                        Toast.makeText(this, "Couldn't save the card", Toast.LENGTH_LONG).show()
                    } else {
                        lastSavedUri = uri
                        if (share && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "image/png"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(Intent.createChooser(send, "Share card"))
                        } else {
                            Toast.makeText(this, "Saved to Pictures/73MCT", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (t: Throwable) {
                main.post { Toast.makeText(this, "Save failed: ${t.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun writePng(bmp: Bitmap, name: String): Uri? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/73MCT")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        }
        // Older Android: write into the app's own pictures folder.
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return null
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return Uri.fromFile(f)
    }
}
