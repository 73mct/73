package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import java.io.File
import kotlin.math.max

/**
 * Profile data (name, bio, bio effect, profile picture, banner). Completely separate from trading data.
 * Pictures are copied into the app's private folder, so GIF / animated WebP keep animating.
 */
object ProfileStore {
    private const val PREFS = "pocketflip_profile"
    const val MAX_BYTES = 15L * 1024L * 1024L

    val effectKeys: List<String> = listOf("none", "shimmer", "typewriter", "glow")
    val effectLabels: List<String> = listOf("Off", "Shimmer", "Typewriter", "Glow")

    private var prefs: SharedPreferences? = null
    private var dir: File? = null

    /** Bumps whenever a picture is saved or removed, so the screen knows to reload it. */
    @Volatile
    var version: Int = 0
        private set

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val app = context.applicationContext
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        dir = File(app.filesDir, "profile").also { it.mkdirs() }
    }

    var name: String
        get() = prefs?.getString("name", "Trader") ?: "Trader"
        set(v) {
            prefs?.edit()?.putString("name", v)?.apply()
        }

    var bio: String
        get() = prefs?.getString("bio", "") ?: ""
        set(v) {
            prefs?.edit()?.putString("bio", v)?.apply()
        }

    var effect: String
        get() = prefs?.getString("effect", "shimmer") ?: "shimmer"
        set(v) {
            prefs?.edit()?.putString("effect", v)?.apply()
        }

    private fun fileFor(kind: String): File? {
        val d = dir ?: return null
        return File(d, "$kind.bin")
    }

    fun hasImage(kind: String): Boolean = fileFor(kind)?.exists() == true

    /** Copies the picked image into private storage. Returns false if it's too big or unreadable. Call off the main thread. */
    fun saveImage(context: Context, uri: Uri, kind: String): Boolean {
        val target = fileFor(kind) ?: return false
        val tmp = File(target.parentFile, "$kind.tmp")
        return try {
            var total = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        total += n
                        if (total > MAX_BYTES) throw IllegalStateException("too big")
                        out.write(buf, 0, n)
                    }
                }
            } ?: return false
            if (total <= 0L) {
                tmp.delete()
                return false
            }
            // Make sure it really is an image before replacing the old one.
            val probe = BitmapFactory.Options()
            probe.inJustDecodeBounds = true
            BitmapFactory.decodeFile(tmp.absolutePath, probe)
            if (probe.outWidth <= 0 || probe.outHeight <= 0) {
                tmp.delete()
                return false
            }
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.delete()
                return false
            }
            version++
            true
        } catch (_: Throwable) {
            tmp.delete()
            false
        }
    }

    fun removeImage(kind: String) {
        fileFor(kind)?.delete()
        version++
    }

    /** Loads the saved picture (animated if it's a GIF / animated WebP). Call off the main thread. */
    fun loadDrawable(context: Context, kind: String, maxSide: Int): Drawable? {
        val f = fileFor(kind) ?: return null
        if (!f.exists()) return null
        if (Build.VERSION.SDK_INT >= 28) {
            val d = decodeApi28(f, maxSide)
            if (d != null) return d
        }
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
            val real = BitmapFactory.Options()
            real.inSampleSize = sample
            val bmp = BitmapFactory.decodeFile(f.absolutePath, real) ?: return null
            BitmapDrawable(context.resources, bmp)
        } catch (_: Throwable) {
            null
        }
    }

    @android.annotation.TargetApi(28)
    private fun decodeApi28(f: File, maxSide: Int): Drawable? {
        return try {
            val src = ImageDecoder.createSource(f)
            ImageDecoder.decodeDrawable(src, ImageDecoder.OnHeaderDecodedListener { decoder, info, _ ->
                val longest = max(info.size.width, info.size.height)
                var k = 1
                while (longest / k > maxSide) k *= 2
                if (k > 1) decoder.setTargetSampleSize(k)
            })
        } catch (_: Throwable) {
            null
        }
    }

    /** Starts looping if the drawable is an animated GIF / WebP (safe on any Android version). */
    fun startIfAnimated(d: Drawable?) {
        if (d == null) return
        if (Build.VERSION.SDK_INT >= 28) startApi28(d)
    }

    @android.annotation.TargetApi(28)
    private fun startApi28(d: Drawable) {
        if (d is AnimatedImageDrawable) {
            d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
            d.start()
        }
    }
}
