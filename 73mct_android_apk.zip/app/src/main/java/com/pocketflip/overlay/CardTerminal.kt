package com.pocketflip.overlay

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The "Terminal" PnL card: the clean layout the big trading terminals use.
 * Small logo top left, name top right, ticker, one solid colored block with the big number,
 * three plain rows, then your picture + handle and a referral line at the bottom.
 * Everything is placed in units (u) measured on a 735 x 499 reference card, so it scales to any size.
 */
object CardTerminal {

    private var emblemSrc: Bitmap? = null
    private var emblemOut: Bitmap? = null

    /** The logo file has a solid black square behind it. This turns that black into transparency
     *  so the logo sits cleanly on any photo or video instead of showing a black box. */
    @Synchronized
    private fun cleanEmblem(src: Bitmap?): Bitmap? {
        if (src == null || src.isRecycled) return null
        if (emblemSrc === src && emblemOut != null) return emblemOut
        return try {
            val w = src.width
            val h = src.height
            val px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            for (i in px.indices) {
                val p = px[i]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val a = max(r, max(g, b))
                val aa = ((a - 10).coerceAtLeast(0) * 255) / 245
                if (a == 0 || aa <= 0) {
                    px[i] = 0
                } else {
                    val rr = min(255, r * 255 / a)
                    val gg = min(255, g * 255 / a)
                    val bb = min(255, b * 255 / a)
                    px[i] = (aa shl 24) or (rr shl 16) or (gg shl 8) or bb
                }
            }
            val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
            emblemSrc = src
            emblemOut = out
            out
        } catch (_: Throwable) {
            src
        }
    }

    private fun regular(o: CardOptions): Typeface = when (o.font) {
        "mono" -> Typeface.MONOSPACE
        "serif" -> Typeface.SERIF
        "cond" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        else -> Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun heavy(o: CardOptions): Typeface = when (o.font) {
        "mono" -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        "serif" -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        "cond" -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        else -> Typeface.create("sans-serif-black", Typeface.NORMAL)
    }

    private fun fmtSol(v: Double): String {
        val a = abs(v)
        return when {
            a >= 1000.0 -> String.format(Locale.US, "%.0f", a)
            a >= 100.0 -> String.format(Locale.US, "%.1f", a)
            a >= 10.0 -> String.format(Locale.US, "%.2f", a)
            else -> String.format(Locale.US, "%.3f", a)
        }
    }

    /** Small three-bar SOL mark. [x],[y] is its top-left, [h] its height. */
    private fun drawSolMark(c: Canvas, x: Float, y: Float, h: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val barH = h * 0.24f
        val gap = (h - barH * 3f) / 2f
        val w = h * 1.05f
        val sk = barH * 0.9f
        for (i in 0..2) {
            val top = y + i * (barH + gap)
            val path = Path()
            if (i == 1) {
                path.moveTo(x, top)
                path.lineTo(x + w - sk, top)
                path.lineTo(x + w, top + barH)
                path.lineTo(x + sk, top + barH)
            } else {
                path.moveTo(x + sk, top)
                path.lineTo(x + w, top)
                path.lineTo(x + w - sk, top + barH)
                path.lineTo(x, top + barH)
            }
            path.close()
            c.drawPath(path, p)
        }
    }

    private fun solMarkWidth(h: Float) = h * 1.05f

    private class Row(val label: String, val value: String, val color: Int?, val sol: Boolean)

    private fun buildRows(
        t: ClosedTradeLog, o: CardOptions, win: Boolean, pnlColor: Int
    ): List<Row> {
        val out = ArrayList<Row>()
        val sign = if (win) "+" else "-"
        for (k in o.tRows.split(",")) {
            when (k.trim()) {
                "pnl" -> out.add(Row("PNL", String.format(Locale.US, "%s%.2f%%", sign, abs(t.roiPct)), pnlColor, false))
                "pnlsol" -> if (!o.hideAmounts) out.add(Row("Profit", sign + fmtSol(t.pnlSol), pnlColor, true))
                "invested" -> if (!o.hideAmounts) out.add(Row("Invested", fmtSol(t.solIn), null, true))
                "returned" -> if (!o.hideAmounts) out.add(Row("Sold", fmtSol(t.solOut), null, true))
                "entry" -> out.add(Row("Entry MC", Formatters.compactUsd(t.entryMc), null, false))
                "exit" -> out.add(Row("Exit MC", Formatters.compactUsd(t.avgExitMc), null, false))
                "peak" -> out.add(Row("Peak MC", Formatters.compactUsd(t.peakMc), null, false))
                "peakx" -> out.add(Row("Peak", Formatters.multX(t.peakX), null, false))
                "held" -> out.add(Row("Held", Formatters.duration(t.holdDurationMs), null, false))
                "fills" -> out.add(Row("Buys / sells", t.buyCount.toString() + " / " + t.sellCount.toString(), null, false))
                else -> {}
            }
        }
        return out
    }

    fun render(
        t: ClosedTradeLog,
        o: CardOptions,
        coin: Bitmap?,
        bgImage: Bitmap?,
        emblem: Bitmap?,
        outWidth: Int,
        progress: Float,
        timeMs: Long
    ): Bitmap {
        val outH = CardRenderer.heightFor(o.aspect, outWidth)
        val bmp = Bitmap.createBitmap(outWidth, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sc = outWidth / CardRenderer.BASE_W
        c.scale(sc, sc)
        val W = CardRenderer.BASE_W
        val H = outH / sc
        val u = min(W / 735f, H / 499f)

        val bg = CardRenderer.col(o.bgHex, Color.BLACK)
        val text = CardRenderer.col(o.textHex, Color.WHITE)
        val accent = CardRenderer.col(o.accentHex, Color.LTGRAY)
        val blockWin = CardRenderer.col(o.tBlockWin, Color.parseColor("#2EE6A6"))
        val blockLoss = CardRenderer.col(o.tBlockLoss, Color.parseColor("#F0357A"))
        val blockText = CardRenderer.col(o.tBlockText, Color.parseColor("#0B0B0B"))
        val win = t.pnlSol >= 0.0
        val blockColor = if (win) blockWin else blockLoss
        val prog = CardRenderer.easeOut(progress)

        // ---------------- background ----------------
        CardRenderer.drawBackground(c, W, H, o, bg, accent, coin, bgImage)
        // darker on the left where the text sits, plus a soft shade top and bottom
        c.drawRect(0f, 0f, W, H, Paint().apply {
            shader = LinearGradient(
                0f, 0f, W * 0.78f, 0f,
                intArrayOf(Color.argb(175, 0, 0, 0), Color.argb(70, 0, 0, 0), Color.TRANSPARENT),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        })
        c.drawRect(0f, 0f, W, H, Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, H,
                intArrayOf(Color.argb(60, 0, 0, 0), Color.TRANSPARENT, Color.argb(130, 0, 0, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        })

        val mx = 31f * u
        val rightX = W - 32f * u

        fun textPaint(size: Float, tf: Typeface, color: Int = text, shadow: Boolean = true) =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                textSize = size
                typeface = tf
                if (shadow) setShadowLayer(7f * u, 0f, 2f * u, Color.argb(110, 0, 0, 0))
            }

        // ---------------- top: logo left, name or logo right ----------------
        val logo = cleanEmblem(emblem)
        val logoSize = 66f * u
        fun drawLogo(left: Float) {
            if (logo != null) {
                val top = 44f * u - logoSize / 2f
                c.drawBitmap(logo, null, RectF(left, top, left + logoSize, top + logoSize), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            }
        }
        if (o.tLeftMark == "coin") {
            if (coin != null && !coin.isRecycled) {
                val r = 27f * u
                drawCoinCircle(c, coin, mx + r, 44f * u, r, t, text, accent)
                c.drawCircle(mx + r, 44f * u, r, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 1.5f * u; color = Theme.alpha(text, 70)
                })
            } else {
                drawLogo(mx - logoSize * 0.13f)   // no coin picture found yet: show your logo instead
            }
        } else if (o.tLeftMark == "logo") drawLogo(mx - logoSize * 0.13f)
        when (o.tRightMark) {
            "logo" -> drawLogo(rightX - logoSize * 0.87f)
            "text" -> {
                val rp = textPaint(36f * u, regular(o))
                rp.textAlign = Paint.Align.RIGHT
                rp.letterSpacing = 0.02f
                c.drawText(
                    CardRenderer.ellipsize(o.tRightText.ifBlank { "73MCT" }, rp, W * 0.5f),
                    rightX, 62f * u, rp
                )
            }
            else -> {}
        }

        // ---------------- rows and hero text ----------------
        val sign = if (win) "+" else "-"
        val mode = if (o.hideAmounts && o.heroMode == "sol") "pct" else o.heroMode
        val heroText: String = when (mode) {
            "pct" -> String.format(Locale.US, "%s%.2f%%", sign, abs(t.roiPct) * prog)
            "multiple" -> String.format(Locale.US, "%.2fx", max(0.0, 1.0 + (t.returnX - 1.0) * prog))
            else -> sign + fmtSol(t.pnlSol * prog)
        }
        val heroIsSol = mode == "sol"
        val rows = if (o.showStats) buildRows(t, o, win, blockColor) else emptyList()

        // vertical placement of the middle group, same proportions as the reference
        val rowGap = 36.5f * u
        val groupH = 22f * u + 140f * u + max(0, rows.size - 1) * rowGap + 6f * u
        val regionTop = 70f * u
        val regionBottom = H - 104f * u
        val slack = max(0f, regionBottom - regionTop - groupH)
        val nameBase = regionTop + slack * 0.55f + 22f * u

        // ticker (and optional coin picture)
        var nameX = mx
        if (o.showCoin) {
            val r = 17f * u
            drawCoinCircle(c, coin, mx + r, nameBase - 10f * u, r, t, text, accent)
            nameX = mx + r * 2f + 12f * u
        }
        val sym = t.symbol.removePrefix("$").ifBlank { t.name }
        val np = textPaint(30f * u, regular(o))
        c.drawText(CardRenderer.ellipsize(sym, np, W - nameX - 40f * u), nameX, nameBase, np)

        // the solid colored block
        val blockTop = nameBase + 18f * u
        val blockH = 69f * u
        val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = blockText
            textSize = 48f * u
            typeface = heavy(o)
            letterSpacing = if (o.font == "mono") 0f else -0.02f
        }
        val markH = 34f * u
        val markW = if (heroIsSol) solMarkWidth(markH) + 10f * u else 0f
        val padIn = 14f * u
        val textW = hp.measureText(heroText)
        val blockW = min(W - mx - 24f * u, max(337f * u, markW + textW + padIn * 2f + 6f * u))
        val rect = RectF(mx - 1f * u, blockTop, mx - 1f * u + blockW, blockTop + blockH)
        val rad = o.tBlockRadius.coerceIn(0, 40) * u
        c.drawRoundRect(rect, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blockColor })
        var hx = rect.left + padIn
        if (heroIsSol) {
            drawSolMark(c, hx, blockTop + blockH / 2f - markH / 2f, markH, blockText)
            hx += markW
        }
        // shrink if it still doesn't fit
        val maxText = rect.right - hx - padIn
        if (textW > maxText && maxText > 0f) hp.textSize = hp.textSize * maxText / textW
        c.drawText(heroText, hx, blockTop + 47f * u, hp)

        // rows: label at 46u, value in a column at 263u
        val labelX = mx + 15f * u
        val valueX = 263f * u
        val lp = textPaint(22.5f * u, regular(o))
        val vp = textPaint(22.5f * u, regular(o))
        var by = blockTop + blockH + 53f * u
        for (r in rows) {
            lp.color = text
            c.drawText(r.label, labelX, by, lp)
            vp.color = r.color ?: text
            var vx = valueX
            if (r.sol) {
                val mh = 18f * u
                drawSolMark(c, vx, by - mh * 0.92f, mh, vp.color)
                vx += solMarkWidth(mh) + 6f * u
            }
            val maxV = W - vx - 24f * u
            c.drawText(CardRenderer.ellipsize(r.value, vp, maxV), vx, by, vp)
            by += rowGap
        }

        // ---------------- bottom: picture, handle, referral line ----------------
        val footBase = H - 44f * u
        val avSize = 40f * u
        val avTop = H - 104f * u
        var hxName = mx
        if (o.showBrand) {
            if (o.showAvatar) {
                drawAvatarSquare(c, mx, avTop, avSize, o, text, accent, timeMs)
                hxName = mx + avSize + 16f * u
            }
            val who = o.handle.ifBlank { o.displayName.ifBlank { "73MCT" } }
            val hpaint = textPaint(30f * u, regular(o))
            c.drawText(CardRenderer.ellipsize(who, hpaint, W - hxName - 190f * u), hxName, avTop + 30f * u, hpaint)
        }
        if (o.tShowFoot) {
            val fs = 14.5f * u
            val globeR = 5.6f * u
            val gcx = mx + globeR + 1f * u
            val gcy = footBase - fs * 0.34f
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 1.2f * u; color = Theme.alpha(text, 225)
            }
            c.drawCircle(gcx, gcy, globeR, gp)
            c.drawOval(RectF(gcx - globeR * 0.45f, gcy - globeR, gcx + globeR * 0.45f, gcy + globeR), gp)
            c.drawLine(gcx - globeR, gcy, gcx + globeR, gcy, gp)
            val fp = textPaint(fs, regular(o), Theme.alpha(text, 235))
            val linkX = mx + globeR * 2f + 8f * u
            val link = CardRenderer.ellipsize(o.tFootLink, fp, W * 0.48f)
            c.drawText(link, linkX, footBase, fp)
            val np2 = textPaint(fs, regular(o), Theme.alpha(text, 215))
            val noteX = linkX + fp.measureText(link) + 19f * u
            c.drawText(CardRenderer.ellipsize(o.tFootNote, np2, W - noteX - 120f * u), noteX, footBase, np2)
        }
        if (o.showPaperTag) {
            val tp = textPaint(12.5f * u, regular(o), Theme.alpha(text, 150))
            tp.textAlign = Paint.Align.RIGHT
            tp.letterSpacing = 0.16f
            c.drawText("PAPER TRADE", rightX, footBase, tp)
        }
        return bmp
    }

    private fun drawAvatarSquare(
        c: Canvas, x: Float, y: Float, s: Float, o: CardOptions, text: Int, accent: Int, timeMs: Long
    ) {
        val rect = RectF(x, y, x + s, y + s)
        val rad = if (o.tAvatarShape == "circle") s / 2f else s * 0.16f
        val a = AvatarAnim.frameAt(timeMs, o.animateAvatar) ?: CardRenderer.avatar
        if (a != null && !a.isRecycled) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val sh = BitmapShader(a, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val m = Matrix()
            val k = s / min(a.width, a.height)
            m.postTranslate(-a.width / 2f, -a.height / 2f)
            m.postScale(k, k)
            m.postTranslate(x + s / 2f, y + s / 2f)
            sh.setLocalMatrix(m)
            p.shader = sh
            c.drawRoundRect(rect, rad, rad, p)
        } else {
            c.drawRoundRect(rect, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent })
            val letter = o.displayName.trim().take(1).uppercase().ifEmpty { "7" }
            val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Theme.onColor(accent); textSize = s * 0.5f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            c.drawText(letter, x + s / 2f, y + s / 2f + s * 0.18f, lp)
        }
    }

    private fun drawCoinCircle(
        c: Canvas, coin: Bitmap?, cx: Float, cy: Float, r: Float,
        t: ClosedTradeLog, text: Int, accent: Int
    ) {
        if (coin != null && !coin.isRecycled) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val sh = BitmapShader(coin, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val m = Matrix()
            val k = (r * 2f) / min(coin.width, coin.height)
            m.postTranslate(-coin.width / 2f, -coin.height / 2f)
            m.postScale(k, k)
            m.postTranslate(cx, cy)
            sh.setLocalMatrix(m)
            p.shader = sh
            c.drawCircle(cx, cy, r, p)
        } else {
            c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(text, 40) })
            val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = r * 1.0f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            val letter = t.symbol.removePrefix("$").take(1).uppercase().ifEmpty { "?" }
            c.drawText(letter, cx, cy + r * 0.35f, lp)
        }
    }
}
