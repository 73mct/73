package com.pocketflip.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile
        var isRunning: Boolean = false

        @Volatile
        private var instance: OverlayService? = null

        fun onInstantScreenMcDetected(screenMc: Double) {
            val svc = instance ?: return
            svc.applyInstantScreenMc(screenMc)
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var rootContainer: FrameLayout
    private lateinit var params: WindowManager.LayoutParams
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null

    // Minimized pill
    private lateinit var pillCard: LinearLayout
    private lateinit var pillIcon: ImageView
    private lateinit var pillTickerText: TextView
    private lateinit var pillPnlText: TextView
    private lateinit var pillMultBadge: TextView
    private lateinit var pillSubText: TextView

    // Expanded trading panel
    private lateinit var hudCard: LinearLayout
    private lateinit var hudTokenIcon: ImageView
    private lateinit var hudTickerText: TextView
    private lateinit var hudNameText: TextView
    private lateinit var hudBanner: TextView
    private lateinit var hudLinksRow: LinearLayout
    private lateinit var dexChip: TextView
    private lateinit var xChip: TextView
    private var linksCa: String = ""
    private var xUrl: String = ""
    private lateinit var hudLiveMcValue: TextView
    private lateinit var hudLivePnlValue: TextView
    private lateinit var hudMultipleValue: TextView
    private lateinit var hudBoughtMcValue: TextView
    private lateinit var hudRealizedValue: TextView
    private lateinit var hudBagLeftValue: TextView
    private lateinit var hudSolBalanceText: TextView
    private lateinit var hudFeeInfoText: TextView
    private lateinit var buyButtonsRow: LinearLayout
    private lateinit var sellButtonsRow: LinearLayout
    private lateinit var customSellPctInput: EditText
    private lateinit var thesisInput: EditText
    private val selectedTags = LinkedHashSet<String>()
    private val thesisChips = ArrayList<Pair<String, TextView>>()

    private val blankToken = TokenInfo(
        ca = "",
        name = "No coin selected",
        symbol = "-",
        priceUsd = 0.0,
        solUsdPrice = 185.0,
        marketCap = 0.0,
        liquidityUsd = 0.0,
        volume24h = 0.0,
        imageUrl = ""
    )

    private var currentToken: TokenInfo = TokenInfo(
        ca = "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr",
        name = "Popcat",
        symbol = "POPCAT",
        priceUsd = 0.0452,
        solUsdPrice = 185.0,
        marketCap = 41890000.0,
        liquidityUsd = 2830000.0,
        volume24h = 10050000.0,
        imageUrl = ""
    )

    // True after the Reset button: ignore late price ticks of the old coin until a new CA is pasted
    @Volatile
    private var panelCleared: Boolean = false

    private var builtThemeVersion: Int = -1
    private var loadedImageUrl: String = ""
    private var lastBitmap: Bitmap? = null
    private var hideBannerRunnable: Runnable? = null
    private var pillFlashUntil: Long = 0L
    private var pillFlashMsg: String = ""

    private val repoListener: () -> Unit = {
        mainHandler.post {
            if (builtThemeVersion != Theme.version) {
                rebuildOverlayForTheme()
            } else {
                refreshHudAndPillUI()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        TradeRepository.init(this)
        ThesisStore.init(this)
        Theme.init(this)
        CoinImages.init(this)
        isRunning = true
        instance = this
        startForegroundServiceNotification()

        if (TradeRepository.settings.activeCa.isBlank()) {
            panelCleared = true
            currentToken = blankToken
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(140)
        }

        buildNativeOverlayViews()
        TradeRepository.addListener(repoListener)
        try {
            windowManager.addView(rootContainer, params)
        } catch (e: Exception) {
            Toast.makeText(this, "Permission required: Enable 'Display over other apps'", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        // Free Shrine live-price WebSocket; HTTP only seeds metadata and checks active CA.
        val wsCallback: (TokenInfo) -> Unit = { liveToken ->
            if (!panelCleared) {
                currentToken = liveToken
                TradeRepository.syncLiveTokenData(liveToken)
                mainHandler.post { refreshHudAndPillUI() }
            }
        }

        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleWithFixedDelay({
            try {
                val activeCa = TradeRepository.settings.activeCa
                if (activeCa.isBlank() || panelCleared) return@scheduleWithFixedDelay
                val token = DexScreenerClient.fetchInitialTokenMetadata(activeCa, wsCallback)
                if (token != null && !panelCleared) {
                    currentToken = token
                    TradeRepository.syncLiveTokenData(token)
                    mainHandler.post { refreshHudAndPillUI() }
                    val imgKey = token.ca + "|" + token.imageUrl
                    if (loadedImageUrl != imgKey) {
                        loadedImageUrl = imgKey
                        loadPanelImage(token)
                    }
                }
            } catch (_: Throwable) {
            }
        }, 0, 2, TimeUnit.SECONDS)
    }

    // =====================================================================
    // UI BUILDING
    // =====================================================================

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams {
        return if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildNativeOverlayViews() {
        builtThemeVersion = Theme.version
        rootContainer = FrameLayout(this)

        val cText = Theme.text
        val cMuted = Theme.muted
        val cBorder = Theme.border
        val cCard = Theme.card
        val cBg = Theme.bg

        // ------------------------------------------------------------------
        // MINIMIZED PILL
        // ------------------------------------------------------------------
        pillCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(14), dp(7))
            background = Theme.surface(dp(22), cText, dp(1), 0xF2)
            visibility = View.GONE
        }

        pillIcon = Theme.avatar(this, dp(30), dp(1)).apply {
            (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(8)
        }

        val pillTextCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pillTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        pillTickerText = tv("\$POPCAT", 12f, cText, bold = true).apply { setPadding(0, 0, dp(6), 0) }
        pillPnlText = tv("+0.000 SOL", 12f, cText, bold = true, mono = true).apply { setPadding(0, 0, dp(6), 0) }
        pillMultBadge = tv("1.00x", 11f, cText, bold = true, mono = true).apply {
            setPadding(dp(6), dp(1), dp(6), dp(1))
            background = Theme.box(Theme.alpha(cText, 0x1F), cBorder, dp(6), dp(1))
        }
        pillTopRow.addView(pillTickerText)
        pillTopRow.addView(pillPnlText)
        pillTopRow.addView(pillMultBadge)

        pillSubText = tv("Tap to trade", 10f, cMuted, mono = true)
        pillTextCol.addView(pillTopRow)
        pillTextCol.addView(pillSubText)

        pillCard.addView(pillIcon)
        pillCard.addView(pillTextCol)

        // ------------------------------------------------------------------
        // EXPANDED TRADING PANEL
        // ------------------------------------------------------------------
        hudCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Theme.surface(dp(22), cBorder, dp(1), 0xF5)
            layoutParams = FrameLayout.LayoutParams(dp(320), FrameLayout.LayoutParams.WRAP_CONTENT)
        }

        // Header (drag handle)
        val hudHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(10), dp(8))
        }

        hudTokenIcon = Theme.avatar(this, dp(34), dp(1)).apply {
            (layoutParams as LinearLayout.LayoutParams).rightMargin = dp(10)
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudTickerText = tv("No coin", 15f, cText, bold = true).apply {
            maxLines = 1
        }
        hudNameText = tv("Tap Paste to load a CA", 10f, cMuted).apply {
            maxLines = 1
        }
        titleCol.addView(hudTickerText)
        titleCol.addView(hudNameText)

        fun headerBtn(label: String, onClick: () -> Unit): TextView {
            return tv(label, 11f, cText, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(10), dp(1))
                layoutParams = lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    leftMargin = dp(5)
                }
                setOnClickListener {
                    pressFx(this)
                    onClick()
                }
            }
        }

        val pasteBtn = headerBtn("Paste CA") { pasteCaFromClipboard() }
        val resetBtn = headerBtn("Reset") { resetPanel() }
        val minimizeBtn = headerBtn("—") { switchToMinimizedPill() }

        hudHeader.addView(hudTokenIcon)
        hudHeader.addView(titleCol)
        hudHeader.addView(pasteBtn)
        hudHeader.addView(resetBtn)
        hudHeader.addView(minimizeBtn)

        // Dex + X link buttons (shown once a coin is loaded)
        fun linkChip(label: String, onClick: () -> Unit): TextView {
            return tv(label, 11f, cText, bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(7), dp(14), dp(7))
                background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(10), dp(1))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                setOnClickListener {
                    pressFx(this)
                    onClick()
                }
            }
        }
        dexChip = linkChip("Dex chart") {
            if (currentToken.ca.isNotBlank()) openLink(CoinLinkFinder.dexUrl(currentToken.ca))
        }
        xChip = linkChip("X search") {
            if (currentToken.ca.isNotBlank()) {
                openLink(if (xUrl.isNotEmpty()) xUrl else CoinLinkFinder.xSearchUrl(currentToken.ca))
            }
        }
        hudLinksRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(12)
                rightMargin = dp(6)
                bottomMargin = dp(6)
            }
            addView(dexChip)
            addView(xChip)
        }

        // Action banner (shows "SOLD 25%" etc.)
        hudBanner = tv("", 12f, cBg, bold = true, mono = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            visibility = View.GONE
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(12)
                rightMargin = dp(12)
                bottomMargin = dp(6)
            }
        }

        val hudBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(2), dp(12), dp(12))
        }

        // Stats box
        val statsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(cBg, cBorder, dp(14), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }

        val statsTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }

        val colMc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f)
        }
        colMc.addView(tv("Market cap", 10f, cMuted))
        hudLiveMcValue = tv("—", 17f, cText, bold = true, mono = true)
        colMc.addView(hudLiveMcValue)

        val colPnl = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
        }
        colPnl.addView(tv("PnL", 10f, cMuted))
        hudLivePnlValue = tv("0.000 SOL", 13f, cMuted, bold = true, mono = true)
        colPnl.addView(hudLivePnlValue)

        val colMult = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
        }
        colMult.addView(tv("Multiple", 10f, cMuted))
        hudMultipleValue = tv("1.00x", 15f, cText, bold = true, mono = true)
        colMult.addView(hudMultipleValue)

        statsTop.addView(colMc)
        statsTop.addView(colPnl)
        statsTop.addView(colMult)

        val divider = View(this).apply {
            setBackgroundColor(cBorder)
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
        }

        val statsSub = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }
        hudBoughtMcValue = tv("Bought —", 10f, cMuted, mono = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudRealizedValue = tv("Realized —", 10f, cMuted, mono = true).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f)
        }
        hudBagLeftValue = tv("Bag 0%", 10f, cMuted, mono = true).apply {
            gravity = Gravity.END
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f)
        }
        statsSub.addView(hudBoughtMcValue)
        statsSub.addView(hudRealizedValue)
        statsSub.addView(hudBagLeftValue)

        statsBox.addView(statsTop)
        statsBox.addView(divider)
        statsBox.addView(statsSub)

        // Buy section
        val buyHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        buyHeaderRow.addView(tv("BUY (SOL)", 11f, cText, bold = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        hudSolBalanceText = tv("Bal 10.00 SOL", 11f, cMuted, mono = true)
        buyHeaderRow.addView(hudSolBalanceText)

        buyButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 4f
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }

        // Sell section
        val sellHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        sellHeaderRow.addView(tv("SELL (% of bag)", 11f, cText, bold = true).apply {
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        hudFeeInfoText = tv("Fee 1% + 0.005 SOL", 10f, cMuted, mono = true)
        sellHeaderRow.addView(hudFeeInfoText)

        sellButtonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 4f
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
        }

        // Custom sell row
        val customSellRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        customSellPctInput = EditText(this).apply {
            hint = "Custom %"
            setText("30")
            setHintTextColor(cMuted)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Theme.box(cBg, cBorder, dp(10), dp(1))
            layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            setOnClickListener { enableKeyboardFocus(true) }
        }

        val customSellBtn = tv("Sell %", 12f, Theme.onColor(Theme.sell), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = Theme.box(Theme.sell, Theme.sell, dp(10), 0)
            layoutParams = lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                rightMargin = dp(6)
            }
            setOnClickListener {
                val pct = customSellPctInput.text.toString().toDoubleOrNull() ?: 30.0
                enableKeyboardFocus(false)
                pressFx(this)
                handleSellClick(pct, this)
            }
        }

        val hideBtn = tv("Hide", 12f, cText, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = Theme.box(Theme.alpha(cText, 0x14), cBorder, dp(10), dp(1))
            setOnClickListener {
                pressFx(this)
                switchToMinimizedPill()
            }
        }

        customSellRow.addView(customSellPctInput)
        customSellRow.addView(customSellBtn)
        customSellRow.addView(hideBtn)

        // Thesis (optional): why this buy? Saved with the trade when you press a buy button.
        thesisChips.clear()
        val thesisBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        thesisInput = EditText(this).apply {
            hint = "Thesis: why this buy? (optional)"
            setHintTextColor(cMuted)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine(true)
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(120))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Theme.box(cBg, cBorder, dp(10), dp(1))
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
            setOnClickListener { enableKeyboardFocus(true) }
        }
        thesisBox.addView(thesisInput)
        val tagRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = ThesisStore.tags.size.toFloat()
            layoutParams = lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        for ((i, tag) in ThesisStore.tags.withIndex()) {
            val chip = tv(tag, 10f, cText, bold = true).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(dp(2), dp(7), dp(2), dp(7))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i < ThesisStore.tags.size - 1) rightMargin = dp(5)
                }
                setOnClickListener {
                    if (selectedTags.contains(tag)) selectedTags.remove(tag) else selectedTags.add(tag)
                    paintThesisChips()
                }
            }
            thesisChips.add(tag to chip)
            tagRow.addView(chip)
        }
        thesisBox.addView(tagRow)
        paintThesisChips()

        hudBody.addView(statsBox)
        hudBody.addView(buyHeaderRow)
        hudBody.addView(thesisBox)
        hudBody.addView(buyButtonsRow)
        hudBody.addView(sellHeaderRow)
        hudBody.addView(sellButtonsRow)
        hudBody.addView(customSellRow)

        hudCard.addView(hudHeader)
        hudCard.addView(hudLinksRow)
        hudCard.addView(hudBanner)
        hudCard.addView(hudBody)

        rootContainer.addView(
            pillCard,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        rootContainer.addView(hudCard)

        // Touch dragging for pill + header
        val dragTouchListener = object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(rootContainer, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && v == pillCard) {
                            switchToExpandedHud()
                        }
                        return true
                    }
                }
                return false
            }
        }

        pillCard.setOnTouchListener(dragTouchListener)
        hudHeader.setOnTouchListener(dragTouchListener)

        lastBitmap?.let { setTokenBitmap(it) }
        rebuildPresetButtons()
        refreshHudAndPillUI()
    }

    private fun rebuildOverlayForTheme() {
        val wasPill = ::pillCard.isInitialized && pillCard.visibility == View.VISIBLE
        try {
            windowManager.removeView(rootContainer)
        } catch (_: Throwable) {
        }
        buildNativeOverlayViews()
        try {
            windowManager.addView(rootContainer, params)
        } catch (_: Throwable) {
        }
        if (wasPill) {
            hudCard.visibility = View.GONE
            pillCard.visibility = View.VISIBLE
        }
    }

    private fun rebuildPresetButtons() {
        buyButtonsRow.removeAllViews()
        val buyFill = Theme.buy
        val buyText = Theme.onColor(buyFill)
        val buys = TradeRepository.settings.buyPresets
        for (i in buys.indices) {
            val amt = buys[i]
            val btn = tv(Formatters.amount(amt), 13f, buyText, bold = true, mono = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(11), dp(4), dp(11))
                background = Theme.box(buyFill, buyFill, dp(12), 0)
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i < buys.size - 1) rightMargin = dp(6)
                }
                setOnClickListener {
                    pressFx(this)
                    handleBuyClick(amt)
                }
            }
            buyButtonsRow.addView(btn)
        }

        sellButtonsRow.removeAllViews()
        val sellColor = Theme.sell
        val sells = TradeRepository.settings.sellPresets
        for (i in sells.indices) {
            val pct = sells[i]
            val btn = tv("${pct.toInt()}%", 13f, sellColor, bold = true, mono = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(11), dp(4), dp(11))
                background = Theme.box(Theme.bg, sellColor, dp(12), dp(2))
                layoutParams = lp(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (i < sells.size - 1) rightMargin = dp(6)
                }
                setOnClickListener {
                    pressFx(this)
                    handleSellClick(pct, this)
                }
            }
            sellButtonsRow.addView(btn)
        }
    }

    // =====================================================================
    // ANIMATIONS / FEEDBACK
    // =====================================================================

    private fun pressFx(v: View) {
        try {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Throwable) {
        }
        v.animate().cancel()
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    /** Fills a sell button solid for a moment so you can see the tap registered. */
    private fun flashSellButton(btn: TextView) {
        val sellColor = Theme.sell
        btn.background = Theme.box(sellColor, sellColor, dp(12), dp(2))
        btn.setTextColor(Theme.onColor(sellColor))
        mainHandler.postDelayed({
            btn.background = Theme.box(Theme.bg, sellColor, dp(12), dp(2))
            btn.setTextColor(sellColor)
        }, 380)
    }

    private fun showBanner(msg: String, ok: Boolean) {
        hideBannerRunnable?.let { mainHandler.removeCallbacks(it) }
        hudBanner.animate().cancel()
        hudBanner.text = msg
        if (ok) {
            hudBanner.background = Theme.box(Theme.text, Theme.text, dp(12), 0)
            hudBanner.setTextColor(Theme.onColor(Theme.text))
        } else {
            hudBanner.background = Theme.box(Theme.bg, Theme.loss, dp(12), dp(1))
            hudBanner.setTextColor(Theme.text)
        }
        hudBanner.visibility = View.VISIBLE
        hudBanner.alpha = 0f
        hudBanner.translationY = -dp(10).toFloat()
        hudBanner.animate().alpha(1f).translationY(0f).setDuration(170).start()

        val r = Runnable {
            hudBanner.animate().alpha(0f).setDuration(260).withEndAction {
                if (hudBanner.alpha < 0.05f) hudBanner.visibility = View.GONE
            }.start()
        }
        hideBannerRunnable = r
        mainHandler.postDelayed(r, 2400)
    }

    private fun flashPill(msg: String) {
        pillFlashMsg = msg
        pillFlashUntil = System.currentTimeMillis() + 2400
        pillSubText.text = msg
        pillCard.animate().cancel()
        pillCard.animate().scaleX(1.08f).scaleY(1.08f).setDuration(110).withEndAction {
            pillCard.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
        }.start()
        mainHandler.postDelayed({ refreshHudAndPillUI() }, 2450)
    }

    private fun pulseBag() {
        hudBagLeftValue.animate().cancel()
        hudBagLeftValue.alpha = 0.15f
        hudBagLeftValue.animate().alpha(1f).setDuration(500).start()
        hudRealizedValue.animate().cancel()
        hudRealizedValue.alpha = 0.15f
        hudRealizedValue.animate().alpha(1f).setDuration(500).start()
    }

    private fun announce(msg: String, ok: Boolean) {
        if (hudCard.visibility == View.VISIBLE) {
            showBanner(msg, ok)
        } else {
            flashPill(msg)
        }
    }

    // =====================================================================
    // ACTIONS
    // =====================================================================

    private fun handleBuyClick(solAmount: Double) {
        if (currentToken.ca.isBlank()) {
            announce("Paste a CA first", false)
            return
        }
        val res = TradeRepository.executeBuy(currentToken, solAmount)
        res.onSuccess { pos ->
            saveThesisFromPanel(pos)
            announce(
                "BOUGHT ${Formatters.amount(solAmount)} SOL  @ ${Formatters.compactUsd(pos.entryMc)}",
                true
            )
            pulseBag()
            refreshHudAndPillUI()
        }.onFailure { err ->
            announce(err.message ?: "Buy failed", false)
        }
    }

    private fun paintThesisChips() {
        for ((tag, chip) in thesisChips) {
            val on = selectedTags.contains(tag)
            chip.setTextColor(if (on) Theme.onColor(Theme.text) else Theme.text)
            chip.background = if (on) Theme.box(Theme.text, Theme.text, dp(10), 0)
            else Theme.box(Theme.bg, Theme.border, dp(10), dp(1))
        }
    }

    /** Saves the thesis the user typed / tagged (if any) with the position that was just bought. */
    private fun saveThesisFromPanel(pos: OpenPosition) {
        try {
            val txt = thesisInput.text.toString().trim()
            if (txt.isNotEmpty() || selectedTags.isNotEmpty()) {
                ThesisStore.save(pos.ca, pos.openedAtMs, txt, selectedTags.toList())
                thesisInput.setText("")
                selectedTags.clear()
                paintThesisChips()
            }
            if (thesisInput.hasFocus()) {
                thesisInput.clearFocus()
                enableKeyboardFocus(false)
            }
        } catch (_: Throwable) {
        }
    }

    private fun handleSellClick(pct: Double, button: TextView?) {
        if (currentToken.ca.isBlank()) {
            announce("Paste a CA first", false)
            return
        }
        val res = TradeRepository.executeSell(currentToken, pct)
        res.onSuccess { r ->
            if (button != null) flashSellButton(button)
            val msg = if (r.closed) {
                "SOLD 100%  •  CLOSED  ${Formatters.solSigned(r.tradePnlSol)}"
            } else {
                "SOLD ${r.soldPct.toInt()}%  ${Formatters.solSigned(r.slicePnlSol)}  •  ${r.remainingPct.toInt()}% left"
            }
            announce(msg, true)
            pulseBag()
            refreshHudAndPillUI()
        }.onFailure { err ->
            announce(err.message ?: "No position to sell", false)
        }
    }

    /** Coin picture for the panel + bubble: letter circle first, then the real picture (with backup sources). */
    private fun loadPanelImage(token: TokenInfo) {
        val ca = token.ca
        val key = ca + "|" + token.imageUrl
        mainHandler.post {
            if (currentToken.ca == ca && !panelCleared) setTokenBitmap(CoinImages.letterBitmap(token.symbol))
        }
        CoinImages.load(ca, token.imageUrl) { bmp ->
            mainHandler.post {
                if (bmp != null && currentToken.ca == ca && !panelCleared) setTokenBitmap(bmp)
            }
            if (bmp == null) {
                // nothing found yet: allow another try in a while
                mainHandler.postDelayed({ if (loadedImageUrl == key) loadedImageUrl = "" }, 45000L)
            }
        }
    }

    private fun setTokenBitmap(bmp: Bitmap?) {
        lastBitmap = bmp
        if (::hudTokenIcon.isInitialized) hudTokenIcon.setImageBitmap(bmp)
        if (::pillIcon.isInitialized) pillIcon.setImageBitmap(bmp)
    }

    private fun openLink(url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Throwable) {
            announce("Couldn't open the link", false)
        }
    }

    private fun applyLinks(links: CoinLinks) {
        xUrl = links.x
        xChip.text = if (xUrl.isNotEmpty()) "X" else "X search"
    }

    /** Looks up the coin's X link once per coin. */
    private fun ensureLinks(ca: String) {
        if (linksCa == ca) return
        linksCa = ca
        xUrl = ""
        xChip.text = "X search"
        val cached = CoinLinkFinder.cached(ca)
        if (cached != null) { applyLinks(cached); return }
        CoinLinkFinder.find(ca) { links ->
            mainHandler.post {
                if (currentToken.ca == ca && !panelCleared) applyLinks(links)
                // a coin with no X link yet: allow another look later
                else if (links.x.isEmpty()) linksCa = ""
            }
            if (links.x.isEmpty()) mainHandler.postDelayed({ if (linksCa == ca && xUrl.isEmpty()) linksCa = "" }, 60000L)
        }
    }

    private fun resetPanel() {
        linksCa = ""
        panelCleared = true
        currentToken = blankToken
        loadedImageUrl = ""
        setTokenBitmap(null)
        enableKeyboardFocus(false)
        TradeRepository.setActiveCa("")
        val hasOpen = TradeRepository.getAllPositions().isNotEmpty()
        announce(if (hasOpen) "Panel cleared • open trades kept" else "Panel cleared • paste a new CA", true)
        refreshHudAndPillUI()
    }

    private fun pasteCaFromClipboard() {
        // Temporarily make window focusable to read Android 10+ clipboard reliably
        enableKeyboardFocus(true)
        mainHandler.postDelayed({
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val raw = clip.getItemAt(0).coerceToText(this).toString()
                    val ca = DexScreenerClient.extractSolanaCa(raw)
                    if (ca.length >= 20) {
                        panelCleared = false
                        loadedImageUrl = ""
                        TradeRepository.setActiveCa(ca)
                        announce("Loading ${Formatters.shortCa(ca)}...", true)
                        Executors.newSingleThreadExecutor().execute {
                            val token = DexScreenerClient.fetchInitialTokenMetadata(ca) { liveTick ->
                                if (!panelCleared) {
                                    currentToken = liveTick
                                    TradeRepository.syncLiveTokenData(liveTick)
                                    mainHandler.post { refreshHudAndPillUI() }
                                }
                            }
                            if (token != null && !panelCleared) {
                                currentToken = token
                                TradeRepository.syncLiveTokenData(token)
                                mainHandler.post { refreshHudAndPillUI() }
                                loadedImageUrl = token.ca + "|" + token.imageUrl
                                loadPanelImage(token)
                            }
                        }
                    } else {
                        announce("Copy a valid Solana CA first", false)
                    }
                } else {
                    announce("Clipboard is empty", false)
                }
            } catch (_: Throwable) {
            } finally {
                enableKeyboardFocus(false)
            }
        }, 120)
    }

    private fun enableKeyboardFocus(focusable: Boolean) {
        params.flags = if (focusable) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        windowManager.updateViewLayout(rootContainer, params)
        if (!focusable) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(rootContainer.windowToken, 0)
        }
    }

    private fun switchToMinimizedPill() {
        enableKeyboardFocus(false)
        hudCard.visibility = View.GONE
        pillCard.visibility = View.VISIBLE
        windowManager.updateViewLayout(rootContainer, params)
    }

    private fun switchToExpandedHud() {
        pillCard.visibility = View.GONE
        hudCard.visibility = View.VISIBLE
        rebuildPresetButtons()
        refreshHudAndPillUI()
        windowManager.updateViewLayout(rootContainer, params)
    }

    fun applyInstantScreenMc(screenMc: Double) {
        if (screenMc <= 0.0 || panelCleared) return
        val oldMc = currentToken.marketCap.coerceAtLeast(1.0)
        val ratio = screenMc / oldMc
        val newPrice = (currentToken.priceUsd * ratio).coerceAtLeast(0.0000000001)
        currentToken = currentToken.copy(
            marketCap = screenMc,
            priceUsd = newPrice
        )
        TradeRepository.syncLiveTokenData(currentToken)
        mainHandler.post { refreshHudAndPillUI() }
    }

    // =====================================================================
    // LIVE REFRESH
    // =====================================================================

    private fun refreshHudAndPillUI() {
        val blank = currentToken.ca.isBlank()
        val sym = if (currentToken.symbol.startsWith("$")) currentToken.symbol else "$${currentToken.symbol}"
        val mcStr = Formatters.compactUsd(currentToken.marketCap)

        hudLinksRow.visibility = if (blank) View.GONE else View.VISIBLE
        if (!blank && !panelCleared) ensureLinks(currentToken.ca)
        xChip.text = if (xUrl.isNotEmpty()) "X" else "X search"
        hudTickerText.text = if (blank) "No coin" else sym
        hudNameText.text = if (blank) "Tap Paste CA to load a coin" else currentToken.name
        pillTickerText.text = if (blank) "No coin" else sym
        hudLiveMcValue.text = if (blank) "—" else mcStr
        hudSolBalanceText.text = String.format("Bal %.2f SOL", TradeRepository.settings.solBalance)
        hudFeeInfoText.text = "Fee ${TradeRepository.settings.platformFeePct}% + ${TradeRepository.settings.priorityFeeSol} SOL"

        val flashing = System.currentTimeMillis() < pillFlashUntil
        val pos = if (blank) null else TradeRepository.getPosition(currentToken.ca)
        if (pos != null && pos.tokensHeld > 0.0) {
            val pnlSol = TradeRepository.computeUnrealizedPnlSol(pos, currentToken.priceUsd)
            val pnlPct = if (pos.solInvested > 0.0) (pnlSol / pos.solInvested) * 100.0 else 0.0
            val multX = if (pos.entryMc > 0.0) (currentToken.marketCap / pos.entryMc) else 1.0
            val pnlColor = Theme.pnlColor(pnlSol)

            val pnlFormatted = "${Formatters.solSigned(pnlSol)} (${Formatters.pctSigned(pnlPct)})"
            val multFormatted = Formatters.multX(multX)
            val remPctInt = pos.remainingPct.toInt()

            hudLivePnlValue.text = pnlFormatted
            hudLivePnlValue.setTextColor(pnlColor)
            hudMultipleValue.text = multFormatted
            hudBoughtMcValue.text = "Bought ${Formatters.compactUsd(pos.entryMc)}"
            hudRealizedValue.text = "Realized ${Formatters.solSigned(pos.realizedPnlSol)}"
            hudRealizedValue.setTextColor(if (pos.fills.any { it.side == "SELL" }) Theme.pnlColor(pos.realizedPnlSol) else Theme.muted)
            hudBagLeftValue.text = "Bag $remPctInt%"

            pillPnlText.text = pnlFormatted
            pillPnlText.setTextColor(pnlColor)
            pillMultBadge.text = multFormatted
            if (!flashing) pillSubText.text = "$remPctInt% bag running • tap to sell"
        } else {
            hudLivePnlValue.text = "0.000 SOL"
            hudLivePnlValue.setTextColor(Theme.muted)
            hudMultipleValue.text = "1.00x"
            hudBoughtMcValue.text = "Bought —"
            hudRealizedValue.text = "Realized —"
            hudRealizedValue.setTextColor(Theme.muted)
            hudBagLeftValue.text = "Bag 0%"

            pillPnlText.text = "0.000 SOL"
            pillPnlText.setTextColor(Theme.muted)
            pillMultBadge.text = "1.00x"
            if (!flashing) pillSubText.text = if (blank) "Tap to open • paste a CA" else "Tap bubble to buy / sell"
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "pocketflip_native_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "73MCT Floating Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the 73MCT floating bubble alive"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)

            val launchIntent = Intent(this, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = Notification.Builder(this, channelId)
                .setContentTitle("73MCT Floating Bubble Active")
                .setContentText("Hovering over fomo & Axiom • Tap to open controls")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .setContentIntent(pendingIntent)
                .build()

            try {
                if (Build.VERSION.SDK_INT >= 34) { // Android 14+ (UpsideDownCake)
                    startForeground(
                        101,
                        notification,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(101, notification)
                }
            } catch (err: Throwable) {
                try {
                    startForeground(101, notification)
                } catch (_: Throwable) {
                }
            }
        }
    }

    override fun onDestroy() {
        isRunning = false
        instance = null
        TradeRepository.removeListener(repoListener)
        poller?.shutdownNow()
        if (::rootContainer.isInitialized) {
            try {
                windowManager.removeView(rootContainer)
            } catch (_: Throwable) {
            }
        }
        super.onDestroy()
    }
}
