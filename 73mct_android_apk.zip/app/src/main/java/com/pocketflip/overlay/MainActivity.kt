package com.pocketflip.overlay

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {

    companion object {
        var lastTab: Int = 0
        private const val REQ_COIN_PICK = 7401
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var tabTrade: LinearLayout
    private lateinit var tabJournal: LinearLayout
    private lateinit var tabSettings: LinearLayout
    private val navIcons = ArrayList<LineIcon>()
    private val navCells = ArrayList<FrameLayout>()
    private lateinit var heroBalance: TextView
    private lateinit var heroSub: TextView
    private var pickCa: String = ""
    private var pickView: ImageView? = null

    private lateinit var headerBalanceText: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var positionsContainer: LinearLayout

    private lateinit var journalNetPnl: TextView
    private lateinit var journalNetSub: TextView
    private lateinit var journalStatsRow: LinearLayout
    private lateinit var journalListContainer: LinearLayout

    private lateinit var detailLayer: ScrollView
    private lateinit var detailContent: LinearLayout

    private var journalSig: String = ""
    private var refreshPending = false
    private var currentTabIdx = 0

    private val repoListener: () -> Unit = {
        mainHandler.post { scheduleRefresh() }
    }

    private fun scheduleRefresh() {
        if (refreshPending) return
        refreshPending = true
        mainHandler.postDelayed({
            refreshPending = false
            refreshMainUI(false)
        }, 350)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TradeRepository.init(this)
        Theme.init(this)
        CoinImages.init(this)

        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg
        applyLightBarsIfNeeded()

        val rootFrame = FrameLayout(this).apply { setBackgroundColor(Theme.bg) }
        // Soft silver glow behind the header: gives the screen depth instead of flat black.
        val glow = View(this).apply {
            val g = GradientDrawable()
            g.shape = GradientDrawable.RECTANGLE
            g.setGradientType(GradientDrawable.RADIAL_GRADIENT)
            g.setGradientRadius(dp(360).toFloat())
            g.setGradientCenter(0.5f, 0f)
            g.setColors(intArrayOf(Theme.alpha(Theme.text, 0x34), Theme.alpha(Theme.text, 0x12), Color.TRANSPARENT))
            background = g
        }
        rootFrame.addView(glow, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(380)))
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---------- Top bar ----------
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        val brand = hstack()
        if (Theme.onColor(Theme.bg) == Color.WHITE) {
            val logo = ImageView(this).apply { setImageResource(R.drawable.emblem) }
            brand.add(logo, w = dp(32), h = dp(32), right = dp(10))
        }
        brand.add(
            tv("73MCT", 22f, Theme.text, bold = true).apply { letterSpacing = 0.12f },
            w = LinearLayout.LayoutParams.WRAP_CONTENT
        )
        topBar.add(brand, w = 0, weight = 1f)
        headerBalanceText = tv("10.000 SOL", 13f, Theme.text, bold = true, mono = true).apply {
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = Theme.box(Theme.card, Theme.border, dp(20), dp(1))
        }
        topBar.addView(headerBalanceText)
        column.addView(topBar)

        // ---------- Scrollable body ----------
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val contentHolder = FrameLayout(this).apply {
            setPadding(dp(14), dp(6), dp(14), dp(110))
        }
        tabTrade = buildTradeTab()
        tabJournal = buildJournalTab()
        tabSettings = buildSettingsTab()
        contentHolder.addView(tabTrade)
        contentHolder.addView(tabJournal)
        contentHolder.addView(tabSettings)
        scroll.addView(contentHolder)
        column.addView(scroll)


        rootFrame.addView(
            column,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        // ---------- Floating pill nav with line icons ----------
        val navPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = Theme.surface(dp(40), Theme.border, dp(1), 0xF6)
            elevation = dp(16).toFloat()
        }
        val kinds = listOf("trade", "journal", "settings")
        for (i in kinds.indices) {
            val cell = FrameLayout(this)
            cell.setOnClickListener { switchTab(i) }
            val icon = LineIcon(kinds[i], Theme.muted)
            val iv = ImageView(this)
            iv.setImageDrawable(icon)
            cell.addView(iv, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            navIcons.add(icon)
            navCells.add(cell)
            val lp = LinearLayout.LayoutParams(dp(62), dp(48))
            lp.leftMargin = dp(2)
            lp.rightMargin = dp(2)
            navPill.addView(cell, lp)
        }
        val navLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        navLp.bottomMargin = dp(16)
        rootFrame.addView(navPill, navLp)

        // ---------- Trade detail layer (opens when a journal card is tapped) ----------
        detailContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(30))
        }
        detailLayer = ScrollView(this).apply {
            setBackgroundColor(Theme.bg)
            visibility = View.GONE
            isClickable = true
            addView(detailContent)
        }
        rootFrame.addView(
            detailLayer,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        setContentView(rootFrame)
        TradeRepository.addListener(repoListener)
        switchTab(lastTab)
    }

    override fun onResume() {
        super.onResume()
        refreshMainUI(true)
    }

    // =====================================================================
    // SMALL UI HELPERS
    // =====================================================================

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    }

    private fun LinearLayout.add(
        view: View,
        top: Int = 0,
        bottom: Int = 0,
        w: Int = LinearLayout.LayoutParams.MATCH_PARENT,
        h: Int = LinearLayout.LayoutParams.WRAP_CONTENT,
        weight: Float = 0f,
        left: Int = 0,
        right: Int = 0
    ) {
        val params = if (weight > 0f) LinearLayout.LayoutParams(w, h, weight) else LinearLayout.LayoutParams(w, h)
        params.topMargin = top
        params.bottomMargin = bottom
        params.leftMargin = left
        params.rightMargin = right
        addView(view, params)
    }

    private fun vstack(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun hstack(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun cardBox(): LinearLayout = vstack().apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = Theme.box(Theme.card, Theme.border, dp(20), dp(1))
        elevation = dp(4).toFloat()
    }

    private fun filledBtn(label: String, onClick: () -> Unit): TextView {
        return tv(label, 14f, Theme.onColor(Theme.text), bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Theme.box(Theme.text, Theme.text, dp(16), 0)
            elevation = dp(3).toFloat()
            pressFx()
            setOnClickListener { onClick() }
        }
    }

    private fun outlineBtn(label: String, color: Int = Theme.text, onClick: () -> Unit): TextView {
        return tv(label, 13f, color, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = Theme.box(Theme.bg, Theme.border, dp(16), dp(1))
            pressFx()
            setOnClickListener { onClick() }
        }
    }

    private fun statCell(label: String, value: String, valueColor: Int = Theme.text): LinearLayout {
        return vstack().apply {
            add(tv(label, 10f, Theme.muted))
            add(tv(value, 14f, valueColor, bold = true, mono = true), top = dp(2))
        }
    }

    @Suppress("ClickableViewAccessibility")
    private fun View.pressFx() {
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun balanceSpan(v: Double): CharSequence {
        val t = String.format(Locale.US, "%.3f", v)
        val full = "$t SOL"
        val sp = SpannableString(full)
        val dot = t.indexOf('.')
        if (dot >= 0) sp.setSpan(ForegroundColorSpan(Theme.muted), dot, t.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(ForegroundColorSpan(Theme.muted), t.length, full.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(RelativeSizeSpan(0.40f), t.length, full.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sp
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2
            val real = BitmapFactory.Options()
            real.inSampleSize = sample
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, real) }
        } catch (_: Throwable) {
            null
        }
    }

    private fun pickCoinImage(iv: ImageView, ca: String) {
        pickCa = ca
        pickView = iv
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(Intent.createChooser(i, "Choose coin picture"), REQ_COIN_PICK)
        } catch (_: Throwable) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_COIN_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val ca = pickCa
        Thread {
            val bmp = decodeScaled(uri, 640)
            mainHandler.post {
                if (bmp == null) {
                    Toast.makeText(this, "Couldn't open that image", Toast.LENGTH_SHORT).show()
                } else {
                    CoinImages.setCustom(ca, bmp)
                    pickView?.setImageBitmap(bmp)
                    refreshMainUI(true)
                    Toast.makeText(this, "Coin picture saved", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun sectionTitle(text: String): TextView {
        return tv(text, 12f, Theme.muted, bold = true).apply { setPadding(dp(4), dp(8), 0, dp(8)) }
    }

    // =====================================================================
    // TAB 1: TRADE
    // =====================================================================

    private fun buildTradeTab(): LinearLayout {
        val tab = vstack()

        tab.add(tv("Paper balance", 12f, Theme.muted, bold = true), top = dp(4))
        heroBalance = tv("10.000 SOL", 46f, Theme.text, bold = true)
        tab.add(heroBalance, top = dp(2))
        heroSub = tv("", 12f, Theme.muted, mono = true)
        tab.add(heroSub, top = dp(4), bottom = dp(18))

        val launchCard = cardBox()
        val statusRow = hstack()
        statusDot = View(this)
        statusRow.add(statusDot, w = dp(10), h = dp(10), right = dp(10))
        statusText = tv("Bubble stopped", 15f, Theme.text, bold = true)
        statusRow.add(statusText, w = 0, weight = 1f)
        launchCard.add(statusRow)
        launchCard.add(
            tv(
                "Launch the bubble, open fomo, copy a CA and tap Paste CA on the panel. Buy, sell in pieces, and collapse it to watch the chart. Reset clears the coin from the panel.",
                12f, Theme.muted
            ),
            top = dp(8), bottom = dp(14)
        )
        launchCard.add(filledBtn("Launch bubble") { startBubbleServiceWithCheck() }, bottom = dp(8))
        launchCard.add(outlineBtn("Stop bubble") {
            stopService(Intent(this@MainActivity, OverlayService::class.java))
            mainHandler.postDelayed({ refreshMainUI(false) }, 200)
        })
        tab.add(launchCard, bottom = dp(12))

        val permCard = cardBox()
        permCard.add(tv("Permissions (Poco / HyperOS)", 13f, Theme.text, bold = true))
        permCard.add(
            tv("Enable 'Display over other apps' and 'Display pop-up windows while running in the background' so the bubble stays on top of fomo.", 11f, Theme.muted),
            top = dp(4), bottom = dp(10)
        )
        permCard.add(outlineBtn("1. Display over other apps") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }, bottom = dp(8))
        permCard.add(outlineBtn("2. Pop-up windows in background") { openHyperOsPermissions() })
        tab.add(permCard, bottom = dp(12))

        tab.add(sectionTitle("OPEN POSITIONS"))
        positionsContainer = vstack()
        tab.add(positionsContainer)
        return tab
    }

    private fun openHyperOsPermissions() {
        var launched = false
        try {
            val miuiIntent = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                putExtra("extra_pkgname", packageName)
            }
            startActivity(miuiIntent)
            launched = true
        } catch (_: Throwable) {
        }
        if (!launched) {
            try {
                val miuiIntent2 = Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                    setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                    putExtra("extra_pkgname", packageName)
                }
                startActivity(miuiIntent2)
                launched = true
            } catch (_: Throwable) {
            }
        }
        if (!launched) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun buildPositionCard(pos: OpenPosition): View {
        val pnlSol = TradeRepository.computeUnrealizedPnlSol(pos, pos.lastPriceUsd)
        val multX = if (pos.entryMc > 0.0) (pos.lastMc / pos.entryMc) else 1.0
        val hasSells = pos.fills.any { it.side == "SELL" }

        val card = hstack().apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Theme.box(Theme.card, Theme.border, dp(20), dp(1))
            elevation = dp(4).toFloat()
        }
        val icon = Theme.avatar(this, dp(42), dp(1))
        CoinImages.bind(icon, pos.ca, pos.symbol, pos.imageUrl)
        card.add(icon, w = dp(42), h = dp(42), right = dp(12))

        val mid = vstack()
        val sym = if (pos.symbol.startsWith("$")) pos.symbol else "$${pos.symbol}"
        mid.add(tv(sym, 15f, Theme.text, bold = true))
        mid.add(
            tv(
                "${Formatters.compactUsd(pos.entryMc)} → ${Formatters.compactUsd(pos.lastMc)}  (${Formatters.multX(multX)})",
                11f, Theme.muted, mono = true
            ),
            top = dp(2)
        )
        val sub = if (hasSells) {
            "${pos.remainingPct.roundToInt()}% left • realized ${Formatters.solSigned(pos.realizedPnlSol)}"
        } else {
            "${pos.remainingPct.roundToInt()}% bag • ${Formatters.solPlain(pos.initialSolInvested)} in"
        }
        mid.add(tv(sub, 10f, Theme.muted, mono = true), top = dp(2))
        card.add(mid, w = 0, weight = 1f)

        card.add(
            tv(Formatters.solSigned(pnlSol), 13f, Theme.pnlColor(pnlSol), bold = true, mono = true).apply {
                gravity = Gravity.END
            },
            w = LinearLayout.LayoutParams.WRAP_CONTENT
        )
        return card
    }

    // =====================================================================
    // TAB 2: JOURNAL
    // =====================================================================

    private fun buildJournalTab(): LinearLayout {
        val tab = vstack()

        val statsCard = cardBox()
        statsCard.add(tv("Net PnL", 11f, Theme.muted))
        journalNetPnl = tv("+0.000 SOL", 30f, Theme.text, bold = true, mono = true)
        statsCard.add(journalNetPnl, top = dp(2))
        journalNetSub = tv("Invested 0.000 SOL  •  Returned 0.000 SOL", 11f, Theme.muted, mono = true)
        statsCard.add(journalNetSub, top = dp(2), bottom = dp(14))
        journalStatsRow = hstack().apply { weightSum = 4f }
        statsCard.add(journalStatsRow, bottom = dp(14))

        val actions = hstack()
        actions.add(outlineBtn("Export CSV") { shareJournalCsv() }, w = 0, weight = 1f, right = dp(8))
        actions.add(outlineBtn("Clear journal", Theme.loss) { confirmClearJournal() }, w = 0, weight = 1f)
        statsCard.add(actions)
        tab.add(statsCard, bottom = dp(12))

        tab.add(sectionTitle("FINISHED TRADES"))
        journalListContainer = vstack()
        tab.add(journalListContainer)
        tab.visibility = View.GONE
        return tab
    }

    private fun confirmClearJournal() {
        AlertDialog.Builder(this)
            .setTitle("Clear journal?")
            .setMessage("This deletes every finished trade. Open positions are kept.")
            .setPositiveButton("Clear") { _, _ ->
                TradeRepository.clearJournal()
                refreshMainUI(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildJournalCard(t: ClosedTradeLog): View {
        val card = vstack().apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Theme.box(Theme.card, Theme.border, dp(20), dp(1))
            elevation = dp(4).toFloat()
            pressFx()
            setOnClickListener { showTradeDetail(t) }
        }

        val top = hstack()
        val icon = Theme.avatar(this, dp(46), dp(1))
        CoinImages.bind(icon, t.ca, t.symbol, t.imageUrl)
        top.add(icon, w = dp(46), h = dp(46), right = dp(12))

        val mid = vstack()
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$${t.symbol}"
        mid.add(tv(t.name, 15f, Theme.text, bold = true).apply { maxLines = 1 })
        mid.add(tv("$sym  •  ${Formatters.shortCa(t.ca)}", 11f, Theme.muted, mono = true), top = dp(2))
        top.add(mid, w = 0, weight = 1f)

        val right = vstack().apply { gravity = Gravity.END }
        right.add(
            tv(Formatters.solSigned(t.pnlSol), 14f, Theme.pnlColor(t.pnlSol), bold = true, mono = true)
                .apply { gravity = Gravity.END }
        )
        right.add(
            tv(Formatters.pctSigned1(t.roiPct), 11f, Theme.pnlColor(t.pnlSol), mono = true)
                .apply { gravity = Gravity.END },
            top = dp(2)
        )
        top.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        card.add(top)

        val line = View(this).apply { setBackgroundColor(Theme.border) }
        card.add(line, top = dp(12), bottom = dp(12), h = dp(1))

        val stats = hstack().apply {
            weightSum = 3f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.inset(dp(14))
        }
        stats.add(statCell("Invested", Formatters.solPlain(t.solIn)), w = 0, weight = 1f)
        stats.add(statCell("Returned", Formatters.solPlain(t.solOut)), w = 0, weight = 1f)
        stats.add(statCell("Exit", Formatters.multX(t.multipleX), Theme.pnlColor(t.pnlSol)), w = 0, weight = 0.8f)
        card.add(stats)

        card.add(
            tv(
                "Bought ${Formatters.compactUsd(t.entryMc)}  →  Sold ${Formatters.compactUsd(t.avgExitMc)}  •  ${t.buyCount} buy / ${t.sellCount} sell",
                10f, Theme.muted, mono = true
            ),
            top = dp(10)
        )
        return card
    }

    private fun showTradeDetail(t: ClosedTradeLog) {
        detailContent.removeAllViews()

        val bar = hstack()
        bar.add(outlineBtn("←  Back") { hideTradeDetail() }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        bar.add(View(this), w = 0, weight = 1f)
        bar.add(outlineBtn("Delete", Theme.loss) {
            AlertDialog.Builder(this)
                .setTitle("Delete this trade?")
                .setMessage("It will be removed from the journal.")
                .setPositiveButton("Delete") { _, _ ->
                    TradeRepository.deleteTrade(t.id)
                    hideTradeDetail()
                    refreshMainUI(true)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }, w = LinearLayout.LayoutParams.WRAP_CONTENT)
        detailContent.add(bar, bottom = dp(14))

        // Header
        val head = hstack()
        val icon = Theme.avatar(this, dp(64), dp(1))
        val imgNote = tv("Looking for the coin picture...", 10f, Theme.muted, mono = true)
        CoinImages.bind(icon, t.ca, t.symbol, t.imageUrl) { bmp ->
            imgNote.text = if (bmp != null) {
                "Picture: ${CoinImages.sourceOf(t.ca)}  •  tap it to change"
            } else {
                "No picture found  •  tap the circle to choose one"
            }
        }
        icon.setOnClickListener { pickCoinImage(icon, t.ca) }
        head.add(icon, w = dp(64), h = dp(64), right = dp(14))
        val headText = vstack()
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$${t.symbol}"
        headText.add(tv(t.name, 20f, Theme.text, bold = true))
        headText.add(tv(sym, 13f, Theme.muted, bold = true, mono = true), top = dp(2))
        headText.add(imgNote, top = dp(6))
        head.add(headText, w = 0, weight = 1f)
        detailContent.add(head, bottom = dp(14))

        // Shareable PnL card (reads this trade only; changes nothing in the journal)
        detailContent.add(filledBtn("Create PnL card") {
            startActivity(
                Intent(this@MainActivity, CardActivity::class.java)
                    .putExtra(CardActivity.EXTRA_TRADE_ID, t.id)
            )
        }, bottom = dp(12))

        // Big PnL card
        val pnlCard = cardBox()
        pnlCard.add(tv("Net PnL", 11f, Theme.muted))
        pnlCard.add(
            tv(Formatters.solSigned(t.pnlSol), 30f, Theme.pnlColor(t.pnlSol), bold = true, mono = true),
            top = dp(2)
        )
        pnlCard.add(
            tv(
                "${Formatters.pctSigned1(t.roiPct)}  •  you put in ${Formatters.solPlain(t.solIn)} and took out ${Formatters.solPlain(t.solOut)}",
                11f, Theme.muted, mono = true
            ),
            top = dp(4)
        )
        detailContent.add(pnlCard, bottom = dp(12))

        // CA card
        val caCard = cardBox()
        caCard.add(tv("Contract address", 11f, Theme.muted))
        caCard.add(tv(t.ca, 12f, Theme.text, mono = true), top = dp(4), bottom = dp(10))
        caCard.add(outlineBtn("Copy CA") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Solana CA", t.ca))
            Toast.makeText(this, "CA copied", Toast.LENGTH_SHORT).show()
        })
        detailContent.add(caCard, bottom = dp(12))

        // Analysis grid
        val captured = if (t.peakMc > 0.0) (t.avgExitMc / t.peakMc) * 100.0 else 0.0
        val grid = cardBox()
        fun gridRow(l1: String, v1: String, c1: Int, l2: String, v2: String, c2: Int) {
            val row = hstack().apply { weightSum = 2f }
            row.add(statCell(l1, v1, c1), w = 0, weight = 1f)
            row.add(statCell(l2, v2, c2), w = 0, weight = 1f)
            grid.add(row, bottom = dp(14))
        }
        gridRow("Invested", Formatters.solPlain(t.solIn), Theme.text, "Returned", Formatters.solPlain(t.solOut), Theme.text)
        gridRow("Return", Formatters.multX(t.returnX), Theme.pnlColor(t.pnlSol), "ROI", Formatters.pctSigned1(t.roiPct), Theme.pnlColor(t.pnlSol))
        gridRow("Bought at (MC)", Formatters.compactUsd(t.entryMc), Theme.text, "Avg sold at (MC)", Formatters.compactUsd(t.avgExitMc), Theme.text)
        gridRow("Peak MC while holding", Formatters.compactUsd(t.peakMc), Theme.text, "Peak multiple", Formatters.multX(t.peakX), Theme.text)
        gridRow("Exit multiple", Formatters.multX(t.multipleX), Theme.text, "Exit vs peak", String.format("%.0f%%", captured), Theme.text)
        gridRow("Held for", Formatters.duration(t.holdDurationMs), Theme.text, "Buys / Sells", "${t.buyCount} / ${t.sellCount}", Theme.text)
        grid.add(tv("Opened ${Formatters.dateTime(t.openedAtMs)}", 10f, Theme.muted, mono = true))
        grid.add(tv("Closed ${Formatters.dateTime(t.closedAtMs)}", 10f, Theme.muted, mono = true), top = dp(2))
        detailContent.add(grid, bottom = dp(12))

        // Timeline of buys & sells
        detailContent.add(sectionTitle("BUYS & SELLS"))
        val timeline = cardBox()
        for ((idx, f) in t.fills.withIndex()) {
            val row = hstack().apply { setPadding(0, dp(8), 0, dp(8)) }
            val isBuy = f.side == "BUY"

            val tag = tv(if (isBuy) "BUY" else "SELL", 11f, if (isBuy) Theme.onColor(Theme.buy) else Theme.sell, bold = true, mono = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = if (isBuy) Theme.box(Theme.buy, Theme.buy, dp(8), 0)
                else Theme.box(Theme.bg, Theme.sell, dp(8), dp(1))
            }
            row.add(tag, w = dp(52), right = dp(12))

            val mid = vstack()
            mid.add(tv("MC ${Formatters.compactUsd(f.mc)}", 13f, Theme.text, bold = true, mono = true))
            val off = max(0L, f.timeMs - t.openedAtMs)
            val offText = if (off < 1000L) "T+0s" else "T+${Formatters.duration(off)}"
            mid.add(tv("$offText • ${Formatters.dateTime(f.timeMs)}", 10f, Theme.muted, mono = true), top = dp(2))
            row.add(mid, w = 0, weight = 1f)

            val right = vstack().apply { gravity = Gravity.END }
            if (isBuy) {
                right.add(tv("-${Formatters.solPlain(f.sol)}", 12f, Theme.text, bold = true, mono = true).apply { gravity = Gravity.END })
                right.add(tv("spent", 10f, Theme.muted, mono = true).apply { gravity = Gravity.END }, top = dp(2))
            } else {
                right.add(tv("+${Formatters.solPlain(f.sol)}", 12f, Theme.text, bold = true, mono = true).apply { gravity = Gravity.END })
                right.add(
                    tv(
                        "${f.pct.roundToInt()}% sold • ${Formatters.solSigned(f.pnlSol)}",
                        10f, Theme.pnlColor(f.pnlSol), mono = true
                    ).apply { gravity = Gravity.END },
                    top = dp(2)
                )
            }
            row.add(right, w = LinearLayout.LayoutParams.WRAP_CONTENT)
            timeline.add(row)

            if (idx < t.fills.size - 1) {
                timeline.add(View(this).apply { setBackgroundColor(Theme.border) }, h = dp(1))
            }
        }
        detailContent.add(timeline)

        detailLayer.visibility = View.VISIBLE
        detailLayer.scrollTo(0, 0)
    }

    private fun hideTradeDetail() {
        detailLayer.visibility = View.GONE
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (::detailLayer.isInitialized && detailLayer.visibility == View.VISIBLE) {
            hideTradeDetail()
        } else {
            super.onBackPressed()
        }
    }

    @Suppress("DEPRECATION")
    private fun applyLightBarsIfNeeded() {
        try {
            if (Theme.onColor(Theme.bg) == Color.BLACK) {
                val flags = window.decorView.systemUiVisibility or
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                window.decorView.systemUiVisibility = flags
            }
        } catch (_: Throwable) {
        }
    }

    // =====================================================================
    // TAB 3: SETTINGS (trading + appearance)
    // =====================================================================

    private fun addLabeledInput(parent: LinearLayout, label: String, initial: String, numeric: Boolean): EditText {
        parent.add(tv(label, 11f, Theme.muted), top = dp(8), bottom = dp(4))
        val input = EditText(this).apply {
            setText(initial)
            setTextColor(Theme.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.MONOSPACE
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.box(Theme.bg, Theme.border, dp(12), dp(1))
        }
        parent.add(input)
        return input
    }

    private fun buildSettingsTab(): LinearLayout {
        val tab = vstack()
        tab.visibility = View.GONE
        val s = TradeRepository.settings

        // ---- Trading ----
        val trading = cardBox()
        trading.add(tv("Trading", 15f, Theme.text, bold = true), bottom = dp(4))
        val balInput = addLabeledInput(trading, "Paper wallet SOL balance", s.solBalance.toString(), true)
        val feeInput = addLabeledInput(trading, "Platform fee %", s.platformFeePct.toString(), true)
        val prioInput = addLabeledInput(trading, "Priority / bribe fee (SOL per tx)", s.priorityFeeSol.toString(), true)
        val slipInput = addLabeledInput(trading, "Simulated slippage %", s.slippagePct.toString(), true)
        val buyInput = addLabeledInput(trading, "4 quick-buy SOL buttons (comma separated)", s.buyPresets.joinToString(", "), false)
        val sellInput = addLabeledInput(
            trading, "4 quick-sell % buttons (comma separated)",
            s.sellPresets.map { it.toInt() }.joinToString(", "), false
        )
        trading.add(filledBtn("Save trading settings") {
            val cur = TradeRepository.settings
            val newBal = balInput.text.toString().toDoubleOrNull() ?: cur.solBalance
            val newFee = feeInput.text.toString().toDoubleOrNull() ?: cur.platformFeePct
            val newPrio = prioInput.text.toString().toDoubleOrNull() ?: cur.priorityFeeSol
            val newSlip = slipInput.text.toString().toDoubleOrNull() ?: cur.slippagePct
            val parsedBuys = buyInput.text.toString().split(",").mapNotNull { it.trim().toDoubleOrNull() }
            val parsedSells = sellInput.text.toString().split(",").mapNotNull { it.trim().toDoubleOrNull() }
            TradeRepository.updateSettings(
                newBalance = newBal,
                platformFeePct = newFee,
                priorityFeeSol = newPrio,
                slippagePct = newSlip,
                buyPresets = if (parsedBuys.size == 4) parsedBuys else cur.buyPresets,
                sellPresets = if (parsedSells.size == 4) parsedSells else cur.sellPresets
            )
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }, top = dp(16))
        tab.add(trading, bottom = dp(12))

        // ---- Appearance ----
        val look = cardBox()
        look.add(tv("Appearance", 15f, Theme.text, bold = true))
        look.add(
            tv("Pick a preset or type your own hex colors. Applies to the app and the floating trading panel.", 11f, Theme.muted),
            top = dp(4), bottom = dp(10)
        )

        val presetNames = Theme.presets.keys.toList()
        var i = 0
        while (i < presetNames.size) {
            val row = hstack()
            for (j in 0..1) {
                if (i + j < presetNames.size) {
                    val name = presetNames[i + j]
                    row.add(
                        outlineBtn(name) { applyThemeValues(Theme.presets[name] ?: emptyMap()) },
                        w = 0, weight = 1f, right = if (j == 0) dp(8) else 0
                    )
                } else {
                    row.add(View(this), w = 0, weight = 1f)
                }
            }
            look.add(row, bottom = dp(8))
            i += 2
        }

        look.add(tv("Custom colors", 12f, Theme.muted, bold = true), top = dp(8), bottom = dp(4))
        val hexInputs = LinkedHashMap<String, EditText>()
        for (slot in Theme.slots) {
            val row = hstack().apply { setPadding(0, dp(4), 0, dp(4)) }
            row.add(tv(slot.label, 12f, Theme.text), w = 0, weight = 1f)

            val swatch = View(this)
            swatch.background = Theme.box(Theme.c(slot.key), Theme.muted, dp(8), dp(1))
            row.add(swatch, w = dp(30), h = dp(30), right = dp(10))

            val input = EditText(this).apply {
                setText(Theme.hexOf(slot.key))
                setTextColor(Theme.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.MONOSPACE
                inputType = InputType.TYPE_CLASS_TEXT
                setSingleLine(true)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = Theme.box(Theme.bg, Theme.border, dp(10), dp(1))
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val parsed = Theme.parseHex(s?.toString() ?: "")
                        if (parsed != null) swatch.background = Theme.box(parsed, Theme.muted, dp(8), dp(1))
                    }
                })
            }
            row.add(input, w = dp(112))
            hexInputs[slot.key] = input
            look.add(row)
        }

        look.add(filledBtn("Apply colors") {
            val values = LinkedHashMap<String, String>()
            for (slot in Theme.slots) {
                val raw = hexInputs[slot.key]?.text?.toString() ?: ""
                if (Theme.parseHex(raw) == null) {
                    Toast.makeText(this, "Invalid color for ${slot.label} (use e.g. #FFFFFF)", Toast.LENGTH_LONG).show()
                    return@filledBtn
                }
                values[slot.key] = raw
            }
            applyThemeValues(values)
        }, top = dp(14), bottom = dp(8))
        look.add(outlineBtn("Reset to Chrome 73 default") {
            applyThemeValues(Theme.presets[Theme.DEFAULT_PRESET] ?: emptyMap())
        })
        tab.add(look)
        return tab
    }

    private fun applyThemeValues(values: Map<String, String>) {
        Theme.applyColors(values)
        TradeRepository.notifyChanged() // makes the floating panel rebuild with the new colors
        Toast.makeText(this, "Colors applied", Toast.LENGTH_SHORT).show()
        recreate()
    }

    // =====================================================================
    // REFRESH
    // =====================================================================

    private fun refreshMainUI(forceJournal: Boolean) {
        val s = TradeRepository.settings
        headerBalanceText.text = String.format("%.3f SOL", s.solBalance)

        val running = OverlayService.isRunning
        statusText.text = if (running) "Bubble active" else "Bubble stopped"
        statusDot.background = if (running) Theme.circle(Theme.text, Theme.text, 0)
        else Theme.circle(Theme.bg, Theme.muted, dp(2))

        // Open positions
        positionsContainer.removeAllViews()
        val openList = TradeRepository.getAllPositions()
        if (openList.isEmpty()) {
            positionsContainer.add(
                tv("No open positions. Paste a CA in the bubble and buy to start.", 12f, Theme.muted).apply {
                    setPadding(dp(4), dp(4), dp(4), dp(4))
                }
            )
        } else {
            for (pos in openList) {
                positionsContainer.add(buildPositionCard(pos), bottom = dp(8))
            }
        }

        // Journal
        val logs = TradeRepository.getJournal()
        var totalPnl = 0.0
        var totalIn = 0.0
        var totalOut = 0.0
        var wins = 0
        var bestX = 0.0
        var totalHold = 0L
        for (l in logs) {
            totalPnl += l.pnlSol
            totalIn += l.solIn
            totalOut += l.solOut
            if (l.pnlSol >= 0.0) wins++
            if (l.multipleX > bestX) bestX = l.multipleX
            totalHold += l.holdDurationMs
        }
        val winRate = if (logs.isNotEmpty()) (wins * 100) / logs.size else 0
        val avgHold = if (logs.isNotEmpty()) totalHold / logs.size else 0L

        heroBalance.text = balanceSpan(s.solBalance)
        heroSub.text = "Journal ${Formatters.solSigned(totalPnl)}  •  ${logs.size} trades  •  ${openList.size} open"
        heroSub.setTextColor(Theme.muted)

        journalNetPnl.text = Formatters.solSigned(totalPnl)
        journalNetPnl.setTextColor(Theme.pnlColor(totalPnl))
        journalNetSub.text = "Invested ${Formatters.solPlain(totalIn)}  •  Returned ${Formatters.solPlain(totalOut)}"

        journalStatsRow.removeAllViews()
        journalStatsRow.add(statCell("Win rate", "$winRate%"), w = 0, weight = 1f)
        journalStatsRow.add(statCell("Trades", "${logs.size}"), w = 0, weight = 1f)
        journalStatsRow.add(statCell("Best X", Formatters.multX(bestX)), w = 0, weight = 1f)
        journalStatsRow.add(statCell("Avg hold", Formatters.duration(avgHold)), w = 0, weight = 1.2f)

        val sig = "${logs.size}:${logs.firstOrNull()?.id ?: ""}"
        if (forceJournal || sig != journalSig) {
            journalSig = sig
            journalListContainer.removeAllViews()
            if (logs.isEmpty()) {
                journalListContainer.add(
                    tv(
                        "No finished trades yet. A trade shows up here once you sell 100% of a coin. Partial sells are saved inside that trade.",
                        12f, Theme.muted
                    ).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
                )
            } else {
                for (item in logs) {
                    journalListContainer.add(buildJournalCard(item), bottom = dp(10))
                }
            }
        }
    }

    // =====================================================================
    // ACTIONS
    // =====================================================================

    private fun startBubbleServiceWithCheck() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please grant 'Display over other apps' permission for 73MCT first",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val svc = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc)
        } else {
            startService(svc)
        }
        Toast.makeText(this, "Bubble launched. Open fomo now.", Toast.LENGTH_SHORT).show()
        mainHandler.postDelayed({ refreshMainUI(false) }, 250)
    }

    private fun csv(v: String): String = "\"" + v.replace("\"", "\"\"") + "\""

    private fun shareJournalCsv() {
        val logs = TradeRepository.getJournal()
        if (logs.isEmpty()) {
            Toast.makeText(this, "No trades in journal yet", Toast.LENGTH_SHORT).show()
            return
        }
        val sb = StringBuilder(
            "TradeId,Name,Ticker,CA,Side,Time,MC,SOL,PctOfBagSold,SlicePnlSol,TradeInvestedSol,TradeReturnedSol,TradePnlSol,TradeRoiPct,EntryMC,AvgExitMC,PeakMC,HoldSeconds\n"
        )
        for (l in logs) {
            for (f in l.fills) {
                sb.append(csv(l.id)).append(',')
                    .append(csv(l.name)).append(',')
                    .append(csv(l.symbol)).append(',')
                    .append(csv(l.ca)).append(',')
                    .append(f.side).append(',')
                    .append(csv(Formatters.dateTime(f.timeMs))).append(',')
                    .append(f.mc).append(',')
                    .append(f.sol).append(',')
                    .append(f.pct).append(',')
                    .append(f.pnlSol).append(',')
                    .append(l.solIn).append(',')
                    .append(l.solOut).append(',')
                    .append(l.pnlSol).append(',')
                    .append(l.roiPct).append(',')
                    .append(l.entryMc).append(',')
                    .append(l.avgExitMc).append(',')
                    .append(l.peakMc).append(',')
                    .append(l.holdDurationMs / 1000L)
                    .append('\n')
            }
        }
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "73MCT Trade Journal CSV")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(Intent.createChooser(sendIntent, "Export 73MCT Trade Journal"))
    }

    private fun switchTab(idx: Int) {
        currentTabIdx = idx
        lastTab = idx
        tabTrade.visibility = if (idx == 0) View.VISIBLE else View.GONE
        tabJournal.visibility = if (idx == 1) View.VISIBLE else View.GONE
        tabSettings.visibility = if (idx == 2) View.VISIBLE else View.GONE

        for (i in navIcons.indices) {
            val active = i == idx
            navIcons[i].setIconColor(if (active) Theme.text else Theme.muted)
            navCells[i].background = if (active) {
                Theme.box(Theme.alpha(Theme.text, 0x2A), Theme.alpha(Theme.text, 0x2A), dp(24), 0)
            } else {
                null
            }
        }
        val shown = when (idx) {
            0 -> tabTrade
            1 -> tabJournal
            else -> tabSettings
        }
        shown.alpha = 0f
        shown.animate().alpha(1f).setDuration(200).start()
        refreshMainUI(true)
    }

    override fun onDestroy() {
        TradeRepository.removeListener(repoListener)
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
