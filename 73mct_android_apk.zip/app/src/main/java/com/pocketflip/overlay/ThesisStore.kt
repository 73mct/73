package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Optional "why did I take this trade" notes. Stored separately from the trading data
 * (keyed by coin + the time the position was opened), so the trade math is never touched.
 */
object ThesisStore {
    private const val PREFS = "pocketflip_thesis"

    val tags: List<String> = listOf("Narrative", "Snipe", "Copy", "Volume")

    data class Thesis(val text: String, val tags: List<String>, val atMs: Long)

    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    private fun key(ca: String, openedAtMs: Long): String = "t:$ca:$openedAtMs"

    fun save(ca: String, openedAtMs: Long, text: String, tagList: List<String>) {
        val o = JSONObject()
        o.put("text", text.trim())
        o.put("tags", JSONArray(tagList))
        o.put("at", System.currentTimeMillis())
        prefs?.edit()?.putString(key(ca, openedAtMs), o.toString())?.apply()
    }

    fun clear(ca: String, openedAtMs: Long) {
        prefs?.edit()?.remove(key(ca, openedAtMs))?.apply()
    }

    fun get(ca: String, openedAtMs: Long): Thesis? {
        val raw = prefs?.getString(key(ca, openedAtMs), null) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("tags")
            val list = ArrayList<String>()
            if (arr != null) for (i in 0 until arr.length()) list.add(arr.optString(i))
            val th = Thesis(o.optString("text", ""), list, o.optLong("at", 0L))
            if (th.text.isBlank() && th.tags.isEmpty()) null else th
        } catch (_: Throwable) {
            null
        }
    }

    /** One line for lists, e.g. "Narrative, Snipe  -  dev is doxxed, volume rising". */
    fun summary(t: Thesis): String {
        val tg = t.tags.joinToString(", ")
        return when {
            tg.isNotEmpty() && t.text.isNotBlank() -> "$tg  -  ${t.text}"
            tg.isNotEmpty() -> tg
            else -> t.text
        }
    }
}
