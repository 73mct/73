package com.pocketflip.overlay

import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** The links a coin's creator listed. Empty strings mean "not listed". */
class CoinLinks(val x: String, val web: String, val telegram: String)

/**
 * Finds a coin's X link. Tries DexScreener first, then pump.fun, then the coin's on-chain metadata.
 * Runs once per coin and remembers the answer. Never touches the price or PnL code.
 */
object CoinLinkFinder {
    private val cache = ConcurrentHashMap<String, CoinLinks>()
    private val running = ConcurrentHashMap<String, Boolean>()
    private val io = Executors.newFixedThreadPool(2)

    fun dexUrl(ca: String) = "https://dexscreener.com/solana/$ca"
    fun xSearchUrl(ca: String) = "https://x.com/search?q=$ca&f=live"

    fun cached(ca: String): CoinLinks? = cache[ca]

    private fun clean(u: String): String {
        val t = u.trim()
        if (t.isEmpty()) return ""
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (t.startsWith("x.com/") || t.startsWith("twitter.com/") || t.startsWith("www.")) return "https://$t"
        return ""
    }

    private fun isX(u: String): Boolean {
        val l = u.lowercase()
        return l.contains("x.com/") || l.contains("twitter.com/")
    }

    fun find(ca: String, cb: (CoinLinks) -> Unit) {
        val hit = cache[ca]
        if (hit != null) { cb(hit); return }
        if (running.putIfAbsent(ca, true) != null) return
        io.execute {
            var x = ""
            var web = ""
            var tg = ""
            // 1) DexScreener
            try {
                val txt = CoinImages.fetchText("https://api.dexscreener.com/latest/dex/tokens/$ca")
                if (txt != null) {
                    val pairs = JSONObject(txt).optJSONArray("pairs")
                    if (pairs != null) {
                        for (i in 0 until pairs.length()) {
                            val info = pairs.optJSONObject(i)?.optJSONObject("info") ?: continue
                            val socials = info.optJSONArray("socials")
                            if (socials != null) {
                                for (k in 0 until socials.length()) {
                                    val so = socials.optJSONObject(k) ?: continue
                                    val type = so.optString("type", "").lowercase()
                                    val url = clean(so.optString("url", ""))
                                    if (url.isEmpty()) continue
                                    if ((type == "twitter" || type == "x" || isX(url)) && x.isEmpty()) x = url
                                    if (type == "telegram" && tg.isEmpty()) tg = url
                                }
                            }
                            val sites = info.optJSONArray("websites")
                            if (sites != null && web.isEmpty() && sites.length() > 0) {
                                web = clean(sites.optJSONObject(0)?.optString("url", "") ?: "")
                            }
                            if (x.isNotEmpty()) break
                        }
                    }
                }
            } catch (_: Throwable) {}
            // 2) pump.fun
            if (x.isEmpty()) {
                try {
                    for (base in listOf("https://frontend-api-v3.pump.fun/coins/", "https://frontend-api.pump.fun/coins/")) {
                        val txt = CoinImages.fetchText(base + ca) ?: continue
                        val o = JSONObject(txt)
                        val tw = clean(o.optString("twitter", ""))
                        if (tw.isNotEmpty()) x = tw
                        if (tg.isEmpty()) tg = clean(o.optString("telegram", ""))
                        if (web.isEmpty()) web = clean(o.optString("website", ""))
                        break
                    }
                } catch (_: Throwable) {}
            }
            // 3) on-chain metadata
            if (x.isEmpty()) {
                try {
                    val txt = CoinImages.chainMetadataText(ca)
                    if (txt != null) {
                        val o = JSONObject(txt)
                        var tw = clean(o.optString("twitter", ""))
                        if (tw.isEmpty()) {
                            val ext = o.optJSONObject("extensions")
                            if (ext != null) tw = clean(ext.optString("twitter", ""))
                        }
                        if (tw.isNotEmpty()) x = tw
                        if (tg.isEmpty()) tg = clean(o.optString("telegram", ""))
                        if (web.isEmpty()) web = clean(o.optString("website", ""))
                    }
                } catch (_: Throwable) {}
            }
            val res = CoinLinks(x, web, tg)
            // keep a "not found" answer only briefly: brand-new coins add their links a little later
            if (x.isNotEmpty()) cache[ca] = res
            running.remove(ca)
            cb(res)
        }
    }
}
