package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Everything the user can customize on a PnL card. Saved so the next card reopens in the same style. */
class CardOptions {
    var aspect: String = "4:5"          // "1:1" | "4:5" | "9:16" | "16:9"
    var bgStyle: String = "chrome"      // "black" | "chrome" | "coin" | "image" | "video"
    var darkness: Int = 35              // 0..95 (dark overlay over image / coin backgrounds)
    var heroMode: String = "sol"        // "sol" | "pct" | "multiple"
    var shader: String = "chrome"       // "clean" | "chrome" | "gold" | "green"
    var chartMode: String = "real"      // "real" (your actual fills) | "stylized" (decorative path)
    var markerStyle: String = "pill"    // "pill" | "dot" | "none"
    var showChart: Boolean = true
    var showCoin: Boolean = true
    var showStats: Boolean = true
    var showCa: Boolean = true
    var showBrand: Boolean = true
    var showPaperTag: Boolean = true
    var showGrain: Boolean = true
    var showVignette: Boolean = true
    var showFrame: Boolean = true
    var cardStyle: String = "axiom"     // "axiom" (clean, default) | "block" | "glass" | "classic" (the old layout)
    var align: String = "left"          // "left" | "center" (big number block)
    var font: String = "sans"           // "sans" | "mono" | "serif" | "cond"
    var heroScale: Int = 100            // 50..150 (% size of the big number)
    var chartScale: Int = 100           // 40..170 (% height of the chart)
    var lineWidth: Int = 5              // 2..12 (chart line thickness)
    var glow: Int = 40                  // 0..100 (soft light behind the number)
    var bgZoom: Int = 100               // 100..180 (% zoom of image / video background)
    var lightSweep: Boolean = true      // a shine passes over the big number
    var tipGlow: Boolean = true         // glowing dot on the head of the chart line
    var bgBlur: Boolean = false         // blur image / video background
    var animateAvatar: Boolean = true   // animated profile picture plays in the video
    var showRoi: Boolean = true         // ROI % and multiple under the big number
    var lineByResult: Boolean = true    // chart line uses the profit / loss color
    var statKeys: String = "invested,entry,exit,held"
    var showAvatar: Boolean = true      // your profile picture on the card
    var showRarity: Boolean = true      // 2x+ and 10x+ get a badge and a glow
    var showThesis: Boolean = false     // one-line thesis under the chart
    var hideAmounts: Boolean = false    // hides SOL amounts (shows % and market caps only)
    var videoUri: String = ""           // background video picked from the gallery
    var videoSec: Int = 8               // length of the exported MP4 in seconds
    var displayName: String = "73MCT"
    var handle: String = ""
    var bgHex: String = "#000000"
    var textHex: String = "#E6E8EB"
    var accentHex: String = "#C9CDD3"
    var profitHex: String = "#E6E8EB"
    var lossHex: String = "#8B8F96"
    // ---- Terminal (Axiom-style) card ----
    var tBlockWin: String = "#2EE6A6"      // colored block when you made money
    var tBlockLoss: String = "#F0357A"     // colored block when you lost money
    var tBlockText: String = "#0B0B0B"     // number inside the block
    var tBlockRadius: Int = 0              // 0..40 corner roundness of the block
    var tRows: String = "pnl,invested,returned"
    var tLeftMark: String = "logo"         // "logo" | "none"
    var tRightMark: String = "text"        // "text" | "logo" | "none"
    var tRightText: String = "73MCT"
    var tAvatarShape: String = "square"    // "square" | "circle"
    var tShowFoot: Boolean = true
    var tFootLink: String = "Your referral link"
    var tFootNote: String = "Use code YOURCODE"

    fun load(p: SharedPreferences) {
        aspect = p.getString("aspect", aspect) ?: aspect
        bgStyle = p.getString("bgStyle", bgStyle) ?: bgStyle
        darkness = p.getInt("darkness", darkness)
        heroMode = p.getString("heroMode", heroMode) ?: heroMode
        shader = p.getString("shader", shader) ?: shader
        chartMode = p.getString("chartMode", chartMode) ?: chartMode
        markerStyle = p.getString("markerStyle", markerStyle) ?: markerStyle
        showChart = p.getBoolean("showChart", showChart)
        showCoin = p.getBoolean("showCoin", showCoin)
        showStats = p.getBoolean("showStats", showStats)
        showCa = p.getBoolean("showCa", showCa)
        showBrand = p.getBoolean("showBrand", showBrand)
        showPaperTag = p.getBoolean("showPaperTag", showPaperTag)
        showGrain = p.getBoolean("showGrain", showGrain)
        showVignette = p.getBoolean("showVignette", showVignette)
        showFrame = p.getBoolean("showFrame", showFrame)
        cardStyle = p.getString("cardStyle", cardStyle) ?: cardStyle
        showAvatar = p.getBoolean("showAvatar", showAvatar)
        showRarity = p.getBoolean("showRarity", showRarity)
        showThesis = p.getBoolean("showThesis", showThesis)
        hideAmounts = p.getBoolean("hideAmounts", hideAmounts)
        videoUri = p.getString("videoUri", videoUri) ?: videoUri
        videoSec = p.getInt("videoSec", videoSec)
        displayName = p.getString("displayName", displayName) ?: displayName
        handle = p.getString("handle", handle) ?: handle
        bgHex = p.getString("bgHex", bgHex) ?: bgHex
        textHex = p.getString("textHex", textHex) ?: textHex
        accentHex = p.getString("accentHex", accentHex) ?: accentHex
        profitHex = p.getString("profitHex", profitHex) ?: profitHex
        lossHex = p.getString("lossHex", lossHex) ?: lossHex
        align = p.getString("align", align) ?: align
        font = p.getString("font", font) ?: font
        heroScale = p.getInt("heroScale", heroScale)
        chartScale = p.getInt("chartScale", chartScale)
        lineWidth = p.getInt("lineWidth", lineWidth)
        glow = p.getInt("glow", glow)
        bgZoom = p.getInt("bgZoom", bgZoom)
        lightSweep = p.getBoolean("lightSweep", lightSweep)
        tipGlow = p.getBoolean("tipGlow", tipGlow)
        bgBlur = p.getBoolean("bgBlur", bgBlur)
        animateAvatar = p.getBoolean("animateAvatar", animateAvatar)
        showRoi = p.getBoolean("showRoi", showRoi)
        lineByResult = p.getBoolean("lineByResult", lineByResult)
        statKeys = p.getString("statKeys", statKeys) ?: statKeys
        tBlockWin = p.getString("tBlockWin", tBlockWin) ?: tBlockWin
        tBlockLoss = p.getString("tBlockLoss", tBlockLoss) ?: tBlockLoss
        tBlockText = p.getString("tBlockText", tBlockText) ?: tBlockText
        tBlockRadius = p.getInt("tBlockRadius", tBlockRadius)
        tRows = p.getString("tRows", tRows) ?: tRows
        tLeftMark = p.getString("tLeftMark", tLeftMark) ?: tLeftMark
        tRightMark = p.getString("tRightMark", tRightMark) ?: tRightMark
        tRightText = p.getString("tRightText", tRightText) ?: tRightText
        tAvatarShape = p.getString("tAvatarShape", tAvatarShape) ?: tAvatarShape
        tShowFoot = p.getBoolean("tShowFoot", tShowFoot)
        tFootLink = p.getString("tFootLink", tFootLink) ?: tFootLink
        tFootNote = p.getString("tFootNote", tFootNote) ?: tFootNote
        // First time on the Terminal card: switch to it once (3:2, white text, no coin). After that your choices stick.
        if (!p.contains("styleV11")) {
            cardStyle = "terminal"
            aspect = "3:2"
            textHex = "#FFFFFF"
            showCoin = false
            showFrame = false
            showGrain = false
            if (bgStyle == "chrome") bgStyle = "black"
        }
        // First time on the new card: switch to the clean look once. After that your choices stick.
        if (!p.contains("styleV10")) {
            markerStyle = "dot"
            showGrain = false
            showFrame = false
        }
    }

    fun save(p: SharedPreferences) {
        p.edit()
            .putString("aspect", aspect).putString("bgStyle", bgStyle).putInt("darkness", darkness)
            .putString("heroMode", heroMode).putString("shader", shader).putString("chartMode", chartMode)
            .putString("markerStyle", markerStyle)
            .putBoolean("showChart", showChart).putBoolean("showCoin", showCoin)
            .putBoolean("showStats", showStats).putBoolean("showCa", showCa)
            .putBoolean("showBrand", showBrand).putBoolean("showPaperTag", showPaperTag)
            .putBoolean("showGrain", showGrain).putBoolean("showVignette", showVignette)
            .putBoolean("showFrame", showFrame)
            .putString("cardStyle", cardStyle).putBoolean("showAvatar", showAvatar)
            .putBoolean("showRarity", showRarity).putBoolean("showThesis", showThesis)
            .putBoolean("hideAmounts", hideAmounts)
            .putString("videoUri", videoUri).putInt("videoSec", videoSec)
            .putString("displayName", displayName).putString("handle", handle)
            .putString("bgHex", bgHex).putString("textHex", textHex).putString("accentHex", accentHex)
            .putString("profitHex", profitHex).putString("lossHex", lossHex)
            .putString("align", align).putString("font", font)
            .putInt("heroScale", heroScale).putInt("chartScale", chartScale)
            .putInt("lineWidth", lineWidth).putInt("glow", glow).putInt("bgZoom", bgZoom)
            .putBoolean("lightSweep", lightSweep).putBoolean("tipGlow", tipGlow)
            .putBoolean("bgBlur", bgBlur).putBoolean("animateAvatar", animateAvatar)
            .putBoolean("showRoi", showRoi).putBoolean("lineByResult", lineByResult)
            .putString("statKeys", statKeys)
            .putString("tBlockWin", tBlockWin).putString("tBlockLoss", tBlockLoss).putString("tBlockText", tBlockText)
            .putInt("tBlockRadius", tBlockRadius).putString("tRows", tRows)
            .putString("tLeftMark", tLeftMark).putString("tRightMark", tRightMark).putString("tRightText", tRightText)
            .putString("tAvatarShape", tAvatarShape).putBoolean("tShowFoot", tShowFoot)
            .putString("tFootLink", tFootLink).putString("tFootNote", tFootNote)
            .putBoolean("styleV10", true)
            .putBoolean("styleV11", true)
            .apply()
    }

    companion object {
        const val PREFS = "pocketflip_card"
        fun open(context: Context): CardOptions {
            val o = CardOptions()
            o.load(context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE))
            return o
        }
    }
}

/**
 * Draws a PnL card for one finished meme-coin trade.
 * The layout is designed on a 1080-wide canvas and scaled to whatever bitmap size you ask for,
 * so the small live preview and the full-size export look identical.
 * [progress] 0..1 drives the count-up and the chart drawing (1 = finished card).
 */
object CardRenderer {

    const val BASE_W = 1080f

    /** Your profile picture (first frame if it is animated). Set by the card screen. */
    @Volatile
    var avatar: Bitmap? = null

    fun heightFor(aspect: String, width: Int): Int = when (aspect) {
        "1:1" -> width
        "9:16" -> (width * 16f / 9f).toInt()
        "16:9" -> (width * 9f / 16f).toInt()
        "3:2" -> (width * 2f / 3f).toInt()
        else -> (width * 1.25f).toInt()
    }

    internal fun col(hex: String, fallback: Int): Int = Theme.parseHex(hex) ?: fallback

    internal fun easeOut(t: Float): Float {
        val x = 1f - t.coerceIn(0f, 1f)
        return 1f - x * x * x
    }

    fun render(
        t: ClosedTradeLog,
        o: CardOptions,
        coin: Bitmap?,
        bgImage: Bitmap?,
        emblem: Bitmap?,
        outWidth: Int,
        progress: Float = 1f,
        timeMs: Long = 0L
    ): Bitmap {
        if (o.cardStyle == "terminal") return CardTerminal.render(t, o, coin, bgImage, emblem, outWidth, progress, timeMs)
        if (o.cardStyle == "axiom") return renderAxiom(t, o, coin, bgImage, outWidth, progress, timeMs)
        if (o.cardStyle != "classic") return renderModern(t, o, coin, bgImage, outWidth, progress, timeMs)
        if (o.aspect == "16:9") return renderWide(t, o, coin, bgImage, emblem, outWidth, progress)
        val outH = heightFor(o.aspect, outWidth)
        val bmp = Bitmap.createBitmap(outWidth, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sc = outWidth / BASE_W
        c.scale(sc, sc)
        val W = BASE_W
        val H = outH / sc
        
        val bg = col(o.bgHex, Color.BLACK)
        val text = col(o.textHex, Color.WHITE)
        val accent = col(o.accentHex, Color.LTGRAY)
        val profit = col(o.profitHex, Color.WHITE)
        val loss = col(o.lossHex, Color.GRAY)
        val win = t.pnlSol >= 0.0
        val resultColor = if (win) profit else loss
        val muted = Theme.alpha(text, 140)

        drawBackground(c, W, H, o, bg, accent, coin, bgImage)

        if (o.showFrame) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2f
                color = Theme.alpha(text, 38)
            }
            c.drawRoundRect(RectF(26f, 26f, W - 26f, H - 26f), 44f, 44f, p)
        }

        val pad = 72f
        val prog = easeOut(progress)

        // ---------------- Header: emblem + name / handle, paper tag ----------------
        val headerY = 96f
        if (o.showBrand) {
            var tx = pad
            if (emblem != null) {
                val size = 64f
                val ep = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN) }
                c.drawBitmap(emblem, null, RectF(pad, headerY - 44f, pad + size, headerY + 20f), ep)
                tx = pad + size + 16f
            }
            val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 34f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                letterSpacing = 0.12f
            }
            c.drawText(o.displayName.ifBlank { "73MCT" }, tx, headerY - 4f, name)
            if (o.handle.isNotBlank()) {
                val h = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 24f; typeface = Typeface.DEFAULT }
                c.drawText(o.handle, tx, headerY + 24f, h)
            }
        }
        if (o.showPaperTag) {
            val label = "PAPER TRADE"
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 22f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                letterSpacing = 0.14f
            }
            val tw = tp.measureText(label)
            val r = RectF(W - pad - tw - 36f, headerY - 36f, W - pad, headerY + 6f)
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; color = Theme.alpha(text, 110)
            }
            c.drawRoundRect(r, 21f, 21f, stroke)
            c.drawText(label, r.left + 18f, r.bottom - 12f, tp)
        }

        // ---------------- Coin row ----------------
        val coinY = when (o.aspect) { "1:1" -> 200f; "9:16" -> 360f; else -> 270f }
        var nameX = pad
        if (o.showCoin) {
            val r = 62f
            val cx = pad + r
            val cy = coinY
            drawCoin(c, coin, cx, cy, r, t, text, bg, accent)
            nameX = pad + r * 2 + 24f
        }
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$" + t.symbol
        val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = text; textSize = 50f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val nm = ellipsize(t.name, nameP, W - nameX - pad)
        c.drawText(nm, nameX, coinY - 6f, nameP)
        val symP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textSize = 34f; typeface = Typeface.MONOSPACE
        }
        c.drawText(sym, nameX, coinY + 40f, symP)

        // ---------------- Hero number ----------------
        val heroY = when (o.aspect) { "1:1" -> 400f; "9:16" -> 760f; else -> 550f }
        val sign = if (win) "+" else "-"
        val heroText: String
        val heroUnit: String
        when (o.heroMode) {
            "pct" -> {
                heroText = String.format(Locale.US, "%s%.1f%%", sign, abs(t.roiPct) * prog)
                heroUnit = "RETURN ON INVESTED SOL"
            }
            "multiple" -> {
                val mult = 1.0 + (t.returnX - 1.0) * prog
                heroText = String.format(Locale.US, "%.2fx", max(0.0, mult))
                heroUnit = "RETURN MULTIPLE"
            }
            else -> {
                heroText = String.format(Locale.US, "%s%.3f", sign, abs(t.pnlSol) * prog)
                heroUnit = "SOL NET PNL"
            }
        }
        val heroP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 170f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            letterSpacing = -0.03f
        }
        val hw = heroP.measureText(heroText)
        if (hw > W - pad * 2) heroP.textSize = heroP.textSize * (W - pad * 2) / hw
        applyHeroShader(heroP, o.shader, resultColor, text, W, heroY)
        c.drawText(heroText, W / 2f, heroY, heroP)

        val unitP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 26f; textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); letterSpacing = 0.16f
        }
        c.drawText(heroUnit, W / 2f, heroY + 48f, unitP)

        // pills: ROI + multiple
        val pillY = heroY + 108f
        val pillText1 = Formatters.pctSigned1(t.roiPct)
        val pillText2 = Formatters.multX(t.returnX)
        drawPill(c, W / 2f - 12f, pillY, pillText1, resultColor, bg, true)
        drawPill(c, W / 2f + 12f, pillY, pillText2, text, bg, false)

        // ---------------- Chart ----------------
        val rowH = if (o.aspect == "1:1") 92f else 108f
        val statsTop = H - 202f - rowH
        val chartTop = pillY + 60f
        var chartBottom = statsTop - 40f
        if (!o.showStats) chartBottom = H - 190f
        if (o.showChart && chartBottom - chartTop > 120f) {
            drawChart(c, t, o, RectF(pad, chartTop, W - pad, chartBottom), accent, resultColor, text, bg, progress)
        }

        // ---------------- Stats ----------------
        if (o.showStats) {
            val items = listOf(
                "INVESTED" to Formatters.solPlain(t.solIn),
                "RETURNED" to Formatters.solPlain(t.solOut),
                "ENTRY MC" to Formatters.compactUsd(t.entryMc),
                "EXIT MC" to Formatters.compactUsd(t.avgExitMc),
                "PEAK MC" to Formatters.compactUsd(t.peakMc),
                "HELD" to Formatters.duration(t.holdDurationMs)
            )
            val colW = (W - pad * 2) / 3f
            val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = muted; textSize = 21f; letterSpacing = 0.12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 35f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            val sep = Paint().apply { color = Theme.alpha(text, 26); strokeWidth = 2f }
            c.drawLine(pad, statsTop - 14f, W - pad, statsTop - 14f, sep)
            for ((i, item) in items.withIndex()) {
                val col = i % 3
                val row = i / 3
                val x = pad + col * colW
                val y = statsTop + 30f + row * rowH
                c.drawText(item.first, x, y, lab)
                val vp = Paint(valP)
                val maxW = colW - 16f
                val w = vp.measureText(item.second)
                if (w > maxW) vp.textSize = vp.textSize * maxW / w
                c.drawText(item.second, x, y + 44f, vp)
            }
        }

        // ---------------- Footer ----------------
        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 22f; typeface = Typeface.MONOSPACE
        }
        val footY = H - 58f
        if (o.showCa) {
            c.drawText("CA  " + Formatters.shortCa(t.ca), pad, footY, foot)
        }
        foot.textAlign = Paint.Align.RIGHT
        c.drawText(Formatters.dateTime(t.closedAtMs), W - pad, footY, foot)

        // ---------------- Overlays ----------------
        if (o.showVignette) {
            val p = Paint().apply {
                shader = RadialGradient(
                    W / 2f, H / 2f, max(W, H) * 0.78f,
                    intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, W, H, p)
        }
        if (o.showGrain) {
            val rnd = Random(73)
            val gp = Paint().apply { strokeWidth = 2f }
            val count = (W * H / 220f).toInt()
            for (i in 0 until count) {
                val a = rnd.nextInt(26)
                gp.color = if (rnd.nextBoolean()) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
                c.drawPoint(rnd.nextFloat() * W, rnd.nextFloat() * H, gp)
            }
        }
        return bmp
    }

    // ------------------------------------------------------------------

    // ------------------------------------------------------------------
    // 16:9 landscape card (designed on the same 1080-wide canvas, 607.5 tall)
    // ------------------------------------------------------------------

    private fun pillWidth(label: String): Float {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 36f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        return tp.measureText(label) + 56f
    }

    private fun renderWide(
        t: ClosedTradeLog,
        o: CardOptions,
        coin: Bitmap?,
        bgImage: Bitmap?,
        emblem: Bitmap?,
        outWidth: Int,
        progress: Float
    ): Bitmap {
        val outH = heightFor(o.aspect, outWidth)
        val bmp = Bitmap.createBitmap(outWidth, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sc = outWidth / BASE_W
        c.scale(sc, sc)
        val W = BASE_W
        val H = outH / sc

        val bg = col(o.bgHex, Color.BLACK)
        val text = col(o.textHex, Color.WHITE)
        val accent = col(o.accentHex, Color.LTGRAY)
        val profit = col(o.profitHex, Color.WHITE)
        val loss = col(o.lossHex, Color.GRAY)
        val win = t.pnlSol >= 0.0
        val resultColor = if (win) profit else loss
        val muted = Theme.alpha(text, 140)

        drawBackground(c, W, H, o, bg, accent, coin, bgImage)

        if (o.showFrame) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2f
                color = Theme.alpha(text, 38)
            }
            c.drawRoundRect(RectF(18f, 18f, W - 18f, H - 18f), 34f, 34f, p)
        }

        val pad = 52f
        val leftW = 450f
        val prog = easeOut(progress)

        // ---- Header: brand left, paper tag right ----
        val headerY = 70f
        if (o.showBrand) {
            var tx = pad
            if (emblem != null) {
                val size = 46f
                val ep = Paint(Paint.FILTER_BITMAP_FLAG).apply {
                    xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
                }
                c.drawBitmap(emblem, null, RectF(pad, headerY - 32f, pad + size, headerY + 14f), ep)
                tx = pad + size + 12f
            }
            val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 27f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                letterSpacing = 0.12f
            }
            c.drawText(o.displayName.ifBlank { "73MCT" }, tx, headerY - 2f, name)
            if (o.handle.isNotBlank()) {
                val h = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 19f }
                c.drawText(o.handle, tx, headerY + 20f, h)
            }
        }
        if (o.showPaperTag) {
            val label = "PAPER TRADE"
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 17f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                letterSpacing = 0.14f
            }
            val tw = tp.measureText(label)
            val r = RectF(W - pad - tw - 30f, headerY - 28f, W - pad, headerY + 6f)
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; color = Theme.alpha(text, 110)
            }
            c.drawRoundRect(r, 17f, 17f, stroke)
            c.drawText(label, r.left + 15f, r.bottom - 10f, tp)
        }

        // ---- Left column: coin, hero number, pills ----
        val coinY = 178f
        var nameX = pad
        if (o.showCoin) {
            val r = 40f
            drawCoin(c, coin, pad + r, coinY, r, t, text, bg, accent)
            nameX = pad + r * 2 + 18f
        }
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$" + t.symbol
        val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = text; textSize = 38f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        c.drawText(ellipsize(t.name, nameP, pad + leftW - nameX), nameX, coinY - 2f, nameP)
        val symP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textSize = 26f; typeface = Typeface.MONOSPACE
        }
        c.drawText(sym, nameX, coinY + 32f, symP)

        val heroY = 334f
        val sign = if (win) "+" else "-"
        val heroText: String
        val heroUnit: String
        when (o.heroMode) {
            "pct" -> {
                heroText = String.format(Locale.US, "%s%.1f%%", sign, abs(t.roiPct) * prog)
                heroUnit = "RETURN ON INVESTED SOL"
            }
            "multiple" -> {
                val mult = 1.0 + (t.returnX - 1.0) * prog
                heroText = String.format(Locale.US, "%.2fx", max(0.0, mult))
                heroUnit = "RETURN MULTIPLE"
            }
            else -> {
                heroText = String.format(Locale.US, "%s%.3f", sign, abs(t.pnlSol) * prog)
                heroUnit = "SOL NET PNL"
            }
        }
        val heroP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 118f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = -0.03f
        }
        val hw = heroP.measureText(heroText)
        if (hw > leftW) heroP.textSize = heroP.textSize * leftW / hw
        applyHeroShader(heroP, o.shader, resultColor, text, W, heroY)
        c.drawText(heroText, pad, heroY, heroP)

        val unitP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 20f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); letterSpacing = 0.16f
        }
        c.drawText(heroUnit, pad, heroY + 36f, unitP)

        val pillY = heroY + 96f
        val pillText1 = Formatters.pctSigned1(t.roiPct)
        val pillText2 = Formatters.multX(t.returnX)
        drawPill(c, pad, pillY, pillText1, resultColor, bg, false)
        drawPill(c, pad + pillWidth(pillText1) + 14f, pillY, pillText2, text, bg, false)

        // ---- Bottom strip: six stats in one row ----
        val sepY = H - 146f
        if (o.showStats) {
            val items = listOf(
                "INVESTED" to Formatters.solPlain(t.solIn),
                "RETURNED" to Formatters.solPlain(t.solOut),
                "ENTRY MC" to Formatters.compactUsd(t.entryMc),
                "EXIT MC" to Formatters.compactUsd(t.avgExitMc),
                "PEAK MC" to Formatters.compactUsd(t.peakMc),
                "HELD" to Formatters.duration(t.holdDurationMs)
            )
            val colW = (W - pad * 2) / 6f
            val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = muted; textSize = 16f; letterSpacing = 0.12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 29f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            val sep = Paint().apply { color = Theme.alpha(text, 26); strokeWidth = 2f }
            c.drawLine(pad, sepY, W - pad, sepY, sep)
            for ((i, item) in items.withIndex()) {
                val x = pad + i * colW
                c.drawText(item.first, x, sepY + 34f, lab)
                val vp = Paint(valP)
                val maxW = colW - 12f
                val w = vp.measureText(item.second)
                if (w > maxW) vp.textSize = vp.textSize * maxW / w
                c.drawText(item.second, x, sepY + 76f, vp)
            }
        }

        // ---- Chart on the right ----
        val chartLeft = pad + leftW + 34f
        val chartTop = 108f
        val chartBottom = if (o.showStats) sepY - 24f else H - 80f
        if (o.showChart && chartBottom - chartTop > 120f) {
            drawChart(c, t, o, RectF(chartLeft, chartTop, W - pad, chartBottom), accent, resultColor, text, bg, progress)
        }

        // ---- Footer ----
        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 18f; typeface = Typeface.MONOSPACE
        }
        val footY = H - 34f
        if (o.showCa) c.drawText("CA  " + Formatters.shortCa(t.ca), pad, footY, foot)
        foot.textAlign = Paint.Align.RIGHT
        c.drawText(Formatters.dateTime(t.closedAtMs), W - pad, footY, foot)

        // ---- Overlays ----
        if (o.showVignette) {
            val p = Paint().apply {
                shader = RadialGradient(
                    W / 2f, H / 2f, max(W, H) * 0.78f,
                    intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, W, H, p)
        }
        if (o.showGrain) {
            val rnd = Random(73)
            val gp = Paint().apply { strokeWidth = 2f }
            val count = (W * H / 220f).toInt()
            for (i in 0 until count) {
                val a = rnd.nextInt(26)
                gp.color = if (rnd.nextBoolean()) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
                c.drawPoint(rnd.nextFloat() * W, rnd.nextFloat() * H, gp)
            }
        }
        return bmp
    }


    // ------------------------------------------------------------------
    // New layouts: "block" (solid number block) and "glass" (floating panel)
    // ------------------------------------------------------------------

    /** 0 = normal, 1 = win, 2 = 2x or more, 3 = 10x or more. */
    private fun tierOf(t: ClosedTradeLog): Int = when {
        t.pnlSol <= 0.0 -> 0
        t.returnX >= 10.0 -> 3
        t.returnX >= 2.0 -> 2
        else -> 1
    }

    private fun glassPanel(c: Canvas, r: RectF, rad: Float, text: Int) {
        c.drawRoundRect(r, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 0, 0, 0) })
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, r.top, 0f, r.bottom, Theme.alpha(text, 34), Theme.alpha(text, 10), Shader.TileMode.CLAMP)
        }
        c.drawRoundRect(r, rad, rad, fill)
        val st = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; color = Theme.alpha(text, 46)
        }
        c.drawRoundRect(r, rad, rad, st)
    }

    private fun drawCircleBitmap(c: Canvas, b: Bitmap, cx: Float, cy: Float, r: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val shader = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val m = android.graphics.Matrix()
        val s = (r * 2f) / min(b.width, b.height)
        m.postTranslate(-b.width / 2f, -b.height / 2f)
        m.postScale(s, s)
        m.postTranslate(cx, cy)
        shader.setLocalMatrix(m)
        p.shader = shader
        c.drawCircle(cx, cy, r, p)
    }

    private fun drawAvatar(c: Canvas, cx: Float, cy: Float, r: Float, o: CardOptions, text: Int, accent: Int, timeMs: Long = 0L) {
        val a = AvatarAnim.frameAt(timeMs, o.animateAvatar) ?: avatar
        if (a != null && !a.isRecycled) {
            drawCircleBitmap(c, a, cx, cy, r)
        } else {
            c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(text, 34) })
            val letter = o.displayName.trim().take(1).uppercase().ifEmpty { "7" }
            val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = r * 1.0f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            c.drawText(letter, cx, cy + r * 0.35f, lp)
        }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = Theme.alpha(accent, 170)
        }
        c.drawCircle(cx, cy, r + 3f, ring)
    }

    /** Small rounded label. Returns its left edge. */
    private fun smallPill(c: Canvas, rightX: Float, cy: Float, label: String, color: Int, size: Float, filled: Boolean): Float {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = if (filled) Theme.onColor(color) else color
            textSize = size
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = 0.12f
        }
        val tw = tp.measureText(label)
        val h = size * 1.9f
        val left = rightX - tw - size * 1.6f
        val r = RectF(left, cy - h / 2f, rightX, cy + h / 2f)
        if (filled) {
            c.drawRoundRect(r, h / 2f, h / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
        } else {
            c.drawRoundRect(r, h / 2f, h / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.argb(90, 0, 0, 0) })
            c.drawRoundRect(r, h / 2f, h / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; this.color = Theme.alpha(color, 120)
            })
        }
        c.drawText(label, left + size * 0.8f, cy + size * 0.36f, tp)
        return left
    }

    private fun renderModern(
        t: ClosedTradeLog,
        o: CardOptions,
        coin: Bitmap?,
        bgImage: Bitmap?,
        outWidth: Int,
        progress: Float,
        timeMs: Long = 0L
    ): Bitmap {
        val wide = o.aspect == "16:9"
        val outH = heightFor(o.aspect, outWidth)
        val bmp = Bitmap.createBitmap(outWidth, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sc = outWidth / BASE_W
        c.scale(sc, sc)
        val W = BASE_W
        val H = outH / sc

        val bg = col(o.bgHex, Color.BLACK)
        val text = col(o.textHex, Color.WHITE)
        val accent = col(o.accentHex, Color.LTGRAY)
        val profit = col(o.profitHex, Color.WHITE)
        val loss = col(o.lossHex, Color.GRAY)
        val win = t.pnlSol >= 0.0
        val resultColor = if (win) profit else loss
        val muted = Theme.alpha(text, 150)
        val block = o.cardStyle == "block"
        val prog = easeOut(progress)
        val tier = if (o.showRarity) tierOf(t) else 0

        drawBackground(c, W, H, o, bg, accent, coin, bgImage)
        // soft shade top and bottom so text stays readable on any background
        c.drawRect(0f, 0f, W, H, Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, H,
                intArrayOf(Color.argb(90, 0, 0, 0), Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        })
        if (o.showFrame) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; color = Theme.alpha(text, 30)
            }
            val m = if (wide) 14f else 22f
            c.drawRoundRect(RectF(m, m, W - m, H - m), 40f, 40f, p)
        }

        val pad = if (wide) 52f else 72f
        val tall = H > 1700f
        val short = !wide && H < 1200f

        // ---------------- layout numbers ----------------
        val headerCy = if (wide) 62f else 118f
        val avR = if (wide) 28f else 42f
        val coinR = if (wide) 34f else if (short) 44f else 52f
        val coinCy = if (wide) 152f else if (short) 262f else if (tall) 340f else 296f
        val heroTop = if (wide) 196f else coinCy + coinR + 38f
        val blockH = if (wide) 150f else if (short) 196f else 232f
        val heroSize = if (wide) 98f else if (short) 126f else 156f
        val blockW = if (wide) 470f else W - pad * 2
        val panelH = if (wide) 104f else if (short) 160f else 188f
        val panelBottom = if (wide) H - 50f else H - 118f
        val panelTop = panelBottom - panelH

        // ---------------- header: avatar + name, paper tag ----------------
        if (o.showBrand) {
            var tx = pad
            if (o.showAvatar) {
                drawAvatar(c, pad + avR, headerCy, avR, o, text, accent, timeMs)
                tx = pad + avR * 2 + 20f
            }
            val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = if (wide) 26f else 34f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            val hasHandle = o.handle.isNotBlank()
            c.drawText(
                o.displayName.ifBlank { "73MCT" }, tx,
                if (hasHandle) headerCy - 3f else headerCy + name.textSize * 0.35f, name
            )
            if (hasHandle) {
                val h = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = if (wide) 18f else 25f }
                c.drawText(o.handle, tx, headerCy + (if (wide) 22f else 30f), h)
            }
        }
        if (o.showPaperTag) {
            smallPill(c, W - pad, headerCy, "PAPER TRADE", text, if (wide) 15f else 20f, false)
        }

        // ---------------- coin row ----------------
        var nameX = pad
        if (o.showCoin) {
            drawCoin(c, coin, pad + coinR, coinCy, coinR, t, text, bg, accent)
            nameX = pad + coinR * 2 + 24f
        }
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$" + t.symbol
        val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = text; textSize = if (wide) 32f else 44f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val badgeRoom = if (tier >= 2) (if (wide) 120f else 190f) else 0f
        val nameMax = (pad + blockW) - nameX - badgeRoom
        c.drawText(ellipsize(t.name, nameP, nameMax), nameX, coinCy - 4f, nameP)
        val symP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textSize = if (wide) 23f else 30f; typeface = Typeface.MONOSPACE
        }
        c.drawText(sym, nameX, coinCy + (if (wide) 28f else 38f), symP)
        if (tier >= 2) {
            val label = if (tier >= 3) "10X+" else "2X+"
            val badgeColor = if (tier >= 3) Color.parseColor("#F4F6F8") else Color.parseColor("#B9BEC6")
            smallPill(c, pad + blockW, coinCy, label, badgeColor, if (wide) 17f else 24f, true)
        }

        // ---------------- hero number ----------------
        val sign = if (win) "+" else "-"
        val mode = if (o.hideAmounts && o.heroMode == "sol") "pct" else o.heroMode
        val heroText: String
        val heroUnit: String
        when (mode) {
            "pct" -> {
                heroText = String.format(Locale.US, "%s%.1f%%", sign, abs(t.roiPct) * prog)
                heroUnit = "RETURN ON INVESTED"
            }
            "multiple" -> {
                val mult = 1.0 + (t.returnX - 1.0) * prog
                heroText = String.format(Locale.US, "%.2fx", max(0.0, mult))
                heroUnit = "RETURN MULTIPLE"
            }
            else -> {
                heroText = String.format(Locale.US, "%s%.3f", sign, abs(t.pnlSol) * prog)
                heroUnit = "SOL NET PNL"
            }
        }

        if (tier >= 2) {
            val a = if (tier >= 3) 90 else 55
            c.drawRect(0f, heroTop - 120f, W, heroTop + blockH + 160f, Paint().apply {
                shader = RadialGradient(
                    pad + blockW * 0.4f, heroTop + blockH / 2f, blockW * 0.95f,
                    intArrayOf(Theme.alpha(accent, a), Color.TRANSPARENT), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
                )
            })
        }

        val innerPad = if (wide) 26f else 40f
        val heroP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = heroSize
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            letterSpacing = -0.03f
        }
        val maxHeroW = blockW - innerPad * 2
        val hw = heroP.measureText(heroText)
        if (hw > maxHeroW) heroP.textSize = heroP.textSize * maxHeroW / hw
        val unitSize = if (wide) 16f else 22f
        val heroBase = heroTop + blockH - (if (wide) 26f else 34f)
        if (block) {
            val r = RectF(pad, heroTop, pad + blockW, heroTop + blockH)
            c.drawRoundRect(r, if (wide) 20f else 28f, if (wide) 20f else 28f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = resultColor
            })
            val onC = Theme.onColor(resultColor)
            heroP.color = onC
            val up = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Theme.alpha(onC, 170); textSize = unitSize; letterSpacing = 0.16f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            c.drawText(heroUnit, pad + innerPad, heroTop + unitSize + (if (wide) 22f else 30f), up)
            c.drawText(heroText, pad + innerPad, heroBase, heroP)
        } else {
            val up = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = muted; textSize = unitSize; letterSpacing = 0.16f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            c.drawText(heroUnit, pad, heroTop + unitSize + 10f, up)
            applyHeroShader(heroP, o.shader, resultColor, text, W, heroBase)
            c.drawText(heroText, pad, heroBase, heroP)
        }

        // pills
        val pillY = heroTop + blockH + (if (wide) 56f else 66f)
        val pillText1 = Formatters.pctSigned1(t.roiPct)
        val pillText2 = Formatters.multX(t.returnX)
        drawPill(c, pad, pillY, pillText1, resultColor, bg, false)
        drawPill(c, pad + pillWidth(pillText1) + 14f, pillY, pillText2, text, bg, false)

        // ---------------- thesis line (optional) ----------------
        var thesisH = 0f
        if (o.showThesis && !wide) {
            val th = ThesisStore.get(t.ca, t.openedAtMs)?.text?.trim().orEmpty()
            if (th.isNotEmpty()) {
                val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(text, 200); textSize = 28f }
                val shown = ellipsize("“" + th.replace('\n', ' ') + "”", tp, W - pad * 2)
                c.drawText(shown, pad, panelTop - 30f, tp)
                thesisH = 64f
            }
        }

        // ---------------- chart ----------------
        if (wide) {
            val left = pad + blockW + 34f
            val bottom = if (o.showStats) panelTop - 20f else H - 70f
            if (o.showChart && bottom - 96f > 100f) {
                drawChart(c, t, o, RectF(left, 100f, W - pad, bottom), accent, resultColor, text, bg, progress)
            }
        } else {
            val top = pillY + 56f
            val bottom = (if (o.showStats) panelTop else panelBottom) - 34f - thesisH
            if (o.showChart && bottom - top > 100f) {
                drawChart(c, t, o, RectF(pad, top, W - pad, bottom), accent, resultColor, text, bg, progress)
            }
        }

        // ---------------- stats panel ----------------
        if (o.showStats) {
            val items = if (o.hideAmounts) listOf(
                "ENTRY MC" to Formatters.compactUsd(t.entryMc),
                "EXIT MC" to Formatters.compactUsd(t.avgExitMc),
                "PEAK MC" to Formatters.compactUsd(t.peakMc),
                "HELD" to Formatters.duration(t.holdDurationMs)
            ) else listOf(
                "INVESTED" to Formatters.solPlain(t.solIn),
                "ENTRY MC" to Formatters.compactUsd(t.entryMc),
                "EXIT MC" to Formatters.compactUsd(t.avgExitMc),
                "HELD" to Formatters.duration(t.holdDurationMs)
            )
            val panel = RectF(pad, panelTop, W - pad, panelBottom)
            glassPanel(c, panel, if (wide) 24f else 34f, text)
            val colW = panel.width() / 4f
            val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = muted; textSize = if (wide) 15f else 20f; letterSpacing = 0.12f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = if (wide) 28f else 38f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            val div = Paint().apply { color = Theme.alpha(text, 30); strokeWidth = 2f }
            for ((i, item) in items.withIndex()) {
                val cx = panel.left + colW * i + colW / 2f
                if (i > 0) {
                    val x = panel.left + colW * i
                    c.drawLine(x, panel.top + panelH * 0.22f, x, panel.bottom - panelH * 0.22f, div)
                }
                c.drawText(item.first, cx, panel.top + panelH * 0.38f, lab)
                val vp = Paint(valP)
                val w = vp.measureText(item.second)
                val maxW = colW - 22f
                if (w > maxW) vp.textSize = vp.textSize * maxW / w
                c.drawText(item.second, cx, panel.top + panelH * 0.74f, vp)
            }
        }

        // ---------------- footer ----------------
        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = if (wide) 17f else 22f; typeface = Typeface.MONOSPACE
        }
        val footY = if (wide) H - 20f else H - 58f
        if (o.showCa) c.drawText("CA  " + Formatters.shortCa(t.ca), pad, footY, foot)
        foot.textAlign = Paint.Align.RIGHT
        c.drawText(Formatters.dateTime(t.closedAtMs), W - pad, footY, foot)

        // ---------------- overlays (gentle on the new looks) ----------------
        if (o.showVignette) {
            val p = Paint().apply {
                shader = RadialGradient(
                    W / 2f, H / 2f, max(W, H) * 0.8f,
                    intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(100, 0, 0, 0)),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, W, H, p)
        }
        if (o.showGrain) {
            val rnd = Random(73)
            val gp = Paint().apply { strokeWidth = 2f }
            val count = (W * H / 400f).toInt()
            for (i in 0 until count) {
                val a = rnd.nextInt(12)
                gp.color = if (rnd.nextBoolean()) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
                c.drawPoint(rnd.nextFloat() * W, rnd.nextFloat() * H, gp)
            }
        }
        return bmp
    }

    // ------------------------------------------------------------------
    // "Axiom" look: one big number, no boxes, a few clean rows, your identity at the bottom
    // ------------------------------------------------------------------

    private fun face(o: CardOptions, bold: Boolean = true): Typeface {
        val st = if (bold) Typeface.BOLD else Typeface.NORMAL
        return when (o.font) {
            "mono" -> Typeface.create(Typeface.MONOSPACE, st)
            "serif" -> Typeface.create(Typeface.SERIF, st)
            "cond" -> Typeface.create("sans-serif-condensed", st)
            else -> Typeface.create("sans-serif-medium", st)
        }
    }

    /** The rows under the chart, in the order you picked them. */
    private fun statItems(t: ClosedTradeLog, o: CardOptions): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (k in o.statKeys.split(",")) {
            when (k.trim()) {
                "invested" -> if (!o.hideAmounts) out.add("Invested" to Formatters.solPlain(t.solIn))
                "returned" -> if (!o.hideAmounts) out.add("Returned" to Formatters.solPlain(t.solOut))
                "entry" -> out.add("Entry MC" to Formatters.compactUsd(t.entryMc))
                "exit" -> out.add("Exit MC" to Formatters.compactUsd(t.avgExitMc))
                "peak" -> out.add("Peak MC" to Formatters.compactUsd(t.peakMc))
                "peakx" -> out.add("Peak multiple" to Formatters.multX(t.peakX))
                "held" -> out.add("Held" to Formatters.duration(t.holdDurationMs))
                "fills" -> out.add("Buys / sells" to (t.buyCount.toString() + " / " + t.sellCount.toString()))
                else -> {}
            }
        }
        return out
    }

    /** Draws a number with the digits after the dot a little dimmer, like a balance. */
    private fun drawSplitNumber(c: Canvas, s: String, x: Float, y: Float, p: Paint) {
        val dot = s.indexOf('.')
        if (dot < 0) {
            c.drawText(s, x, y, p)
            return
        }
        val head = s.substring(0, dot + 1)
        val tail = s.substring(dot + 1)
        var digitsEnd = 0
        while (digitsEnd < tail.length && tail[digitsEnd].isDigit()) digitsEnd++
        val digits = tail.substring(0, digitsEnd)
        val suffix = tail.substring(digitsEnd)
        c.drawText(head, x, y, p)
        var cx = x + p.measureText(head)
        val dim = Paint(p)
        dim.alpha = 135
        c.drawText(digits, cx, y, dim)
        cx += p.measureText(digits)
        if (suffix.isNotEmpty()) c.drawText(suffix, cx, y, p)
    }

    private fun drawOverlays(c: Canvas, W: Float, H: Float, o: CardOptions) {
        if (o.showVignette) {
            val p = Paint().apply {
                shader = RadialGradient(
                    W / 2f, H / 2f, max(W, H) * 0.8f,
                    intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(100, 0, 0, 0)),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, W, H, p)
        }
        if (o.showGrain) {
            val rnd = Random(73)
            val gp = Paint().apply { strokeWidth = 2f }
            val count = (W * H / 400f).toInt()
            for (i in 0 until count) {
                val a = rnd.nextInt(12)
                gp.color = if (rnd.nextBoolean()) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
                c.drawPoint(rnd.nextFloat() * W, rnd.nextFloat() * H, gp)
            }
        }
    }

    private fun renderAxiom(
        t: ClosedTradeLog,
        o: CardOptions,
        coin: Bitmap?,
        bgImage: Bitmap?,
        outWidth: Int,
        progress: Float,
        timeMs: Long
    ): Bitmap {
        val wide = o.aspect == "16:9"
        val outH = heightFor(o.aspect, outWidth)
        val bmp = Bitmap.createBitmap(outWidth, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sc = outWidth / BASE_W
        c.scale(sc, sc)
        val W = BASE_W
        val H = outH / sc

        val bg = col(o.bgHex, Color.BLACK)
        val text = col(o.textHex, Color.WHITE)
        val accent = col(o.accentHex, Color.LTGRAY)
        val profit = col(o.profitHex, Color.WHITE)
        val loss = col(o.lossHex, Color.GRAY)
        val win = t.pnlSol >= 0.0
        val resultColor = if (win) profit else loss
        val muted = Theme.alpha(text, 150)
        val prog = easeOut(progress)
        val tier = if (o.showRarity) tierOf(t) else 0
        val center = o.align == "center" && !wide
        val short = !wide && H < 1200f
        val tall = H > 1700f
        val lineCol = if (o.lineByResult) resultColor else accent

        drawBackground(c, W, H, o, bg, accent, coin, bgImage)
        // soft shade at top and bottom so text is readable on any picture or video
        c.drawRect(0f, 0f, W, H, Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, H,
                intArrayOf(Color.argb(80, 0, 0, 0), Color.TRANSPARENT, Color.argb(170, 0, 0, 0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
        })
        if (o.showFrame) {
            val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; color = Theme.alpha(text, 28)
            }
            val m = if (wide) 14f else 24f
            c.drawRoundRect(RectF(m, m, W - m, H - m), 40f, 40f, fp)
        }

        // ---------------- layout numbers ----------------
        val pad = if (wide) 56f else 80f
        val hs = o.heroScale.coerceIn(50, 150) / 100f
        val coinR = if (wide) 30f else if (short) 38f else 44f
        val headerCy = if (wide) 64f else if (short) 108f else if (tall) 190f else 150f
        val labelSize = if (wide) 17f else if (short) 22f else 24f
        val labelY = headerCy + coinR + (if (wide) 52f else if (short) 56f else 86f)
        val heroSize = (if (wide) 100f else if (short) 128f else if (tall) 188f else 168f) * hs
        val heroBase = labelY + 20f + heroSize * 0.80f
        val roiSize = if (wide) 34f else if (short) 40f else 48f
        val roiBase = heroBase + roiSize + (if (wide) 22f else 30f)
        val avR = if (wide) 24f else if (short) 30f else 38f
        val idCy = if (wide) H - 50f else if (short) H - 74f else H - 108f
        val items = if (o.showStats) statItems(t, o) else emptyList()
        val rowH = if (short) 54f else 66f
        val statsBottom = idCy - avR - (if (short) 24f else 40f)
        val statsTop = if (wide) H - 214f else statsBottom - items.size * rowH

        var thesis = ""
        if (o.showThesis && !wide) {
            thesis = ThesisStore.get(t.ca, t.openedAtMs)?.text?.trim().orEmpty().replace('\n', ' ')
        }
        val thesisH = if (thesis.isNotEmpty()) 60f else 0f

        // ---------------- soft light behind the number ----------------
        val glowA = (o.glow.coerceIn(0, 100) * 0.75f + (if (tier >= 3) 60 else if (tier == 2) 30 else 0)).toInt().coerceIn(0, 200)
        if (glowA > 0) {
            val gx = if (center) W / 2f else pad + 260f
            val gy = heroBase - heroSize * 0.3f
            c.drawRect(0f, 0f, W, H, Paint().apply {
                shader = RadialGradient(
                    gx, gy, W * 0.85f,
                    intArrayOf(Theme.alpha(resultColor, glowA), Color.TRANSPARENT),
                    floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
                )
            })
        }

        // ---------------- header: coin + ticker on the left, tags on the right ----------------
        var nameX = pad
        if (o.showCoin) {
            drawCoin(c, coin, pad + coinR, headerCy, coinR, t, text, bg, accent)
            nameX = pad + coinR * 2 + 22f
        }
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$" + t.symbol
        val headMax = W - nameX - pad - (if (wide) 170f else 230f)
        val symP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = text; textSize = if (wide) 34f else 44f; typeface = face(o)
        }
        c.drawText(ellipsize(sym, symP, headMax), nameX, headerCy - 2f, symP)
        val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = if (wide) 18f else 25f; typeface = face(o, false)
        }
        c.drawText(ellipsize(t.name, nameP, headMax), nameX, headerCy + (if (wide) 26f else 36f), nameP)

        if (o.showPaperTag) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = muted; textSize = if (wide) 15f else 19f; letterSpacing = 0.2f
                typeface = face(o); textAlign = Paint.Align.RIGHT
            }
            c.drawText("PAPER TRADE", W - pad, headerCy - 4f, tp)
        }
        if (tier >= 2) {
            val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = if (wide) 24f else 32f; letterSpacing = 0.08f
                typeface = face(o); textAlign = Paint.Align.RIGHT
            }
            c.drawText(if (tier >= 3) "10X+" else "2X+", W - pad, headerCy + (if (wide) 26f else 38f), rp)
        }

        // ---------------- the big number ----------------
        val sign = if (win) "+" else "-"
        val mode = if (o.hideAmounts && o.heroMode == "sol") "pct" else o.heroMode
        val heroText: String
        val heroUnit: String
        when (mode) {
            "pct" -> {
                heroText = String.format(Locale.US, "%s%.1f%%", sign, abs(t.roiPct) * prog)
                heroUnit = "RETURN ON INVESTED"
            }
            "multiple" -> {
                val mult = 1.0 + (t.returnX - 1.0) * prog
                heroText = String.format(Locale.US, "%.2fx", max(0.0, mult))
                heroUnit = "RETURN MULTIPLE"
            }
            else -> {
                heroText = String.format(Locale.US, "%s%.3f", sign, abs(t.pnlSol) * prog)
                heroUnit = "REALIZED PNL  ·  SOL"
            }
        }
        val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = labelSize; letterSpacing = 0.2f; typeface = face(o, false)
            textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        }
        c.drawText(heroUnit, if (center) W / 2f else pad, labelY, labelP)

        val heroP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = heroSize; typeface = face(o)
            letterSpacing = if (o.font == "mono") 0f else -0.03f
        }
        val maxW = W - pad * 2
        var hw = heroP.measureText(heroText)
        if (hw > maxW) {
            heroP.textSize = heroP.textSize * maxW / hw
            hw = heroP.measureText(heroText)
        }
        val hx = if (center) (W - hw) / 2f else pad
        applyHeroShader(heroP, o.shader, resultColor, text, W, heroBase)
        drawSplitNumber(c, heroText, hx, heroBase, heroP)

        if (o.lightSweep) {
            val still = timeMs <= 0L
            val ph = if (still) 0.34f else ((timeMs - 2200L).coerceAtLeast(0L) % 3400L) / 3400f
            val sx = -260f + (W + 520f) * ph
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = heroP.textSize; typeface = heroP.typeface; letterSpacing = heroP.letterSpacing
                shader = LinearGradient(
                    sx - 170f, heroBase - heroSize, sx + 170f, heroBase,
                    intArrayOf(Color.TRANSPARENT, Color.argb(if (still) 70 else 190, 255, 255, 255), Color.TRANSPARENT),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
            }
            c.drawText(heroText, hx, heroBase, sp)
        }

        // ROI and multiple as plain text (no boxes)
        if (o.showRoi) {
            val a = Formatters.pctSigned1(t.roiPct)
            val b = Formatters.multX(t.returnX)
            val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = roiSize; typeface = face(o); color = resultColor }
            val mp = Paint(rp).apply { color = muted }
            val gap = roiSize * 0.9f
            val showA = mode != "pct"
            val showB = mode != "multiple"
            val total = (if (showA) rp.measureText(a) else 0f) + (if (showA && showB) gap else 0f) +
                (if (showB) mp.measureText(b) else 0f)
            var rx = if (center) (W - total) / 2f else pad
            if (showA) {
                c.drawText(a, rx, roiBase, rp)
                rx += rp.measureText(a) + gap
            }
            if (showB) c.drawText(b, rx, roiBase, mp)
        }

        // ---------------- chart ----------------
        val chartRect: RectF = if (wide) {
            RectF(620f, 56f, W - pad, if (items.isEmpty()) idCy - 56f else statsTop - 24f)
        } else {
            val bottom = statsTop - 30f - thesisH
            val top0 = roiBase + 40f
            var h = (bottom - top0) * (o.chartScale.coerceIn(40, 170) / 100f)
            h = min(h, bottom - (roiBase + 12f))
            RectF(pad - 10f, bottom - h, W - pad + 10f, bottom)
        }
        if (o.showChart && chartRect.height() > 90f) {
            drawChart(
                c, t, o, chartRect, accent, resultColor, text, bg, progress,
                lineW = o.lineWidth.coerceIn(2, 12).toFloat(), guides = false, tip = o.tipGlow, lineColor = lineCol
            )
        }

        // ---------------- thesis (optional) ----------------
        if (thesis.isNotEmpty()) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(text, 200); textSize = 28f; typeface = face(o, false) }
            val shown = ellipsize("“" + thesis + "”", tp, W - pad * 2)
            c.drawText(shown, pad, statsTop - 26f, tp)
        }

        // ---------------- rows ----------------
        if (items.isNotEmpty()) {
            val line = Paint().apply { color = Theme.alpha(text, 24); strokeWidth = 2f }
            if (wide) {
                val colW = (W - pad * 2) / items.size
                val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 16f; typeface = face(o, false) }
                val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = text; textSize = 30f; typeface = face(o) }
                c.drawLine(pad, statsTop, W - pad, statsTop, line)
                for ((i, item) in items.withIndex()) {
                    val x = pad + colW * i
                    c.drawText(item.first, x, statsTop + 40f, lab)
                    val vp = Paint(valP)
                    val w = vp.measureText(item.second)
                    val mw = colW - 18f
                    if (w > mw) vp.textSize = vp.textSize * mw / w
                    c.drawText(item.second, x, statsTop + 86f, vp)
                }
            } else {
                val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = muted; textSize = if (short) 24f else 28f; typeface = face(o, false)
                }
                val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = text; textSize = if (short) 30f else 34f; typeface = face(o); textAlign = Paint.Align.RIGHT
                }
                for ((i, item) in items.withIndex()) {
                    val top = statsTop + i * rowH
                    val base = top + rowH * 0.64f
                    c.drawText(item.first, pad, base, lab)
                    c.drawText(item.second, W - pad, base, valP)
                    if (i < items.size - 1) c.drawLine(pad, top + rowH, W - pad, top + rowH, line)
                }
            }
        }

        // ---------------- identity row: your picture, name, handle; date and CA ----------------
        val nameSize = if (wide) 24f else if (short) 28f else 32f
        var tx = pad
        if (o.showBrand) {
            if (o.showAvatar) {
                drawAvatar(c, pad + avR, idCy, avR, o, text, accent, timeMs)
                tx = pad + avR * 2 + 20f
            }
            val idMax = W - tx - pad - (if (wide) 230f else 300f)
            val np = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = text; textSize = nameSize; typeface = face(o) }
            val hasHandle = o.handle.isNotBlank()
            c.drawText(
                ellipsize(o.displayName.ifBlank { "73MCT" }, np, idMax), tx,
                if (hasHandle) idCy - 2f else idCy + nameSize * 0.35f, np
            )
            if (hasHandle) {
                val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = nameSize * 0.76f; typeface = face(o, false) }
                c.drawText(ellipsize(o.handle, hp, idMax), tx, idCy + nameSize * 0.9f, hp)
            }
        }
        val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = if (wide) 15f else if (short) 19f else 22f
            typeface = Typeface.MONOSPACE; textAlign = Paint.Align.RIGHT
        }
        c.drawText(Formatters.dateTime(t.closedAtMs), W - pad, if (o.showCa) idCy - 2f else idCy + fp.textSize * 0.35f, fp)
        if (o.showCa) c.drawText("CA " + Formatters.shortCa(t.ca), W - pad, idCy + fp.textSize * 1.35f, fp)

        drawOverlays(c, W, H, o)
        return bmp
    }

    internal fun ellipsize(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 1 && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    internal fun drawBackground(
        c: Canvas, W: Float, H: Float, o: CardOptions, bg: Int, accent: Int,
        coin: Bitmap?, bgImage: Bitmap?
    ) {
        val fill = Paint().apply { color = bg }
        c.drawRect(0f, 0f, W, H, fill)
        val dark = (o.darkness.coerceIn(0, 95) / 100f * 255).toInt()
        when (o.bgStyle) {
            "chrome" -> {
                val glow = Paint().apply {
                    shader = RadialGradient(
                        W * 0.5f, H * 0.08f, W * 0.95f,
                        intArrayOf(Theme.alpha(accent, 70), Theme.alpha(accent, 18), Color.TRANSPARENT),
                        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                    )
                }
                c.drawRect(0f, 0f, W, H, glow)
                val glow2 = Paint().apply {
                    shader = RadialGradient(
                        W * 0.95f, H * 1.02f, W * 0.8f,
                        intArrayOf(Theme.alpha(accent, 38), Color.TRANSPARENT),
                        floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
                    )
                }
                c.drawRect(0f, 0f, W, H, glow2)
            }
            "coin" -> if (coin != null) {
                drawCover(c, blur(coin), W, H)
                c.drawRect(0f, 0f, W, H, Paint().apply { color = Color.argb(max(dark, 120), 0, 0, 0) })
            }
            "image", "video" -> if (bgImage != null) {
                val src = if (o.bgBlur) softBlur(bgImage) else bgImage
                drawCover(c, src, W, H, o.bgZoom.coerceIn(100, 200) / 100f)
                c.drawRect(0f, 0f, W, H, Paint().apply { color = Color.argb(dark, 0, 0, 0) })
            }
            else -> {}
        }
    }

    /** Cheap blur: shrink a lot, scale back up with smoothing. */
    private fun blur(src: Bitmap): Bitmap {
        val small = Bitmap.createScaledBitmap(src, max(8, src.width / 24), max(8, src.height / 24), true)
        return Bitmap.createScaledBitmap(small, 256, 256, true)
    }

    /** Blur that keeps the picture's shape (used for image / video backgrounds). */
    private fun softBlur(src: Bitmap): Bitmap {
        val w = max(8, src.width / 16)
        val h = max(8, src.height / 16)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        return Bitmap.createScaledBitmap(small, max(64, src.width / 2), max(64, src.height / 2), true)
    }

    private fun drawCover(c: Canvas, b: Bitmap, W: Float, H: Float, zoom: Float = 1f) {
        val s = max(W / b.width, H / b.height) * zoom
        val w = b.width * s
        val h = b.height * s
        val l = (W - w) / 2f
        val tp = (H - h) / 2f
        c.drawBitmap(b, null, RectF(l, tp, l + w, tp + h), Paint(Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawCoin(c: Canvas, coin: Bitmap?, cx: Float, cy: Float, r: Float, t: ClosedTradeLog, text: Int, bg: Int, accent: Int) {
        if (coin != null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val shader = BitmapShader(coin, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val m = android.graphics.Matrix()
            val s = (r * 2f) / min(coin.width, coin.height)
            m.postTranslate(-coin.width / 2f, -coin.height / 2f)
            m.postScale(s, s)
            m.postTranslate(cx, cy)
            shader.setLocalMatrix(m)
            p.shader = shader
            c.drawCircle(cx, cy, r, p)
        } else {
            // Letter placeholder so the card never has an empty hole.
            val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(text, 34) }
            c.drawCircle(cx, cy, r, fillP)
            val letter = t.symbol.trimStart('$').take(1).uppercase().ifEmpty { "?" }
            val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = r * 1.1f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            c.drawText(letter, cx, cy + r * 0.38f, lp)
        }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = Theme.alpha(accent, 150)
        }
        c.drawCircle(cx, cy, r + 3f, ring)
    }

    private fun applyHeroShader(p: Paint, style: String, resultColor: Int, text: Int, W: Float, baseY: Float) {
        val top = baseY - 150f
        when (style) {
            "chrome" -> p.shader = LinearGradient(
                0f, top, 0f, baseY,
                intArrayOf(Color.parseColor("#FFFFFF"), Color.parseColor("#C9CDD3"), Color.parseColor("#6E727A"), Color.parseColor("#E8EAED")),
                floatArrayOf(0f, 0.45f, 0.62f, 1f), Shader.TileMode.CLAMP
            )
            "gold" -> p.shader = LinearGradient(
                0f, top, 0f, baseY,
                intArrayOf(Color.parseColor("#FFF3B0"), Color.parseColor("#E8B923"), Color.parseColor("#8A5A00"), Color.parseColor("#F7D154")),
                floatArrayOf(0f, 0.45f, 0.65f, 1f), Shader.TileMode.CLAMP
            )
            "green" -> p.shader = LinearGradient(
                0f, top, 0f, baseY,
                intArrayOf(Color.parseColor("#B8FFD6"), Color.parseColor("#22C55E"), Color.parseColor("#0B7A3B")),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            else -> p.color = if (resultColor == text) text else resultColor
        }
    }

    private fun drawPill(c: Canvas, anchorX: Float, y: Float, label: String, color: Int, bg: Int, rightAligned: Boolean) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = 36f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val tw = tp.measureText(label)
        val w = tw + 56f
        val left = if (rightAligned) anchorX - w else anchorX
        val r = RectF(left, y - 38f, left + w, y + 22f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Theme.alpha(color, 30) }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; this.color = Theme.alpha(color, 120)
        }
        c.drawRoundRect(r, 30f, 30f, fill)
        c.drawRoundRect(r, 30f, 30f, stroke)
        c.drawText(label, r.left + 28f, r.bottom - 15f, tp)
    }

    // ------------------------------------------------------------------
    // Chart
    // ------------------------------------------------------------------

    private data class Pt(val x: Float, val y: Float, val side: String?)

    /** Market cap path built from the trade's real fills (and the peak, so you can see what you left behind). */
    private fun realPoints(t: ClosedTradeLog): List<Pt> {
        val fills = t.fills.sortedBy { it.timeMs }
        if (fills.isEmpty()) return emptyList()
        val t0 = fills.first().timeMs
        val span = max(1L, fills.last().timeMs - t0).toFloat()
        val raw = fills.map { Triple((it.timeMs - t0) / span, it.mc.toFloat(), it.side) }
        return raw.map { Pt(it.first, it.second, it.third) }
    }

    /** Decorative path from entry to peak to exit. Same start, peak and end as the trade; the wiggles between are invented. */
    private fun stylizedPoints(t: ClosedTradeLog): List<Pt> {
        val rnd = Random(t.id.hashCode().toLong())
        val entry = t.entryMc.toFloat()
        val exit = t.avgExitMc.toFloat()
        val peak = max(t.peakMc.toFloat(), max(entry, exit))
        val n = 24
        val peakAt = 0.62f
        val out = ArrayList<Pt>()
        for (i in 0 until n) {
            val x = i / (n - 1f)
            val base = if (x <= peakAt) {
                val k = x / peakAt
                entry + (peak - entry) * (k * k * (3f - 2f * k))
            } else {
                val k = (x - peakAt) / (1f - peakAt)
                peak + (exit - peak) * (k * k * (3f - 2f * k))
            }
            val amp = (peak - min(entry, exit)).coerceAtLeast(entry * 0.05f) * 0.07f
            val noise = if (i == 0 || i == n - 1) 0f else (rnd.nextFloat() - 0.5f) * 2f * amp
            val side = when (i) { 0 -> "BUY"; n - 1 -> "SELL"; else -> null }
            out.add(Pt(x, max(base + noise, entry * 0.2f), side))
        }
        return out
    }

    private fun drawChart(
        c: Canvas, t: ClosedTradeLog, o: CardOptions, area: RectF,
        accent: Int, resultColor: Int, text: Int, bg: Int, progress: Float,
        lineW: Float = 5f, guides: Boolean = true, tip: Boolean = false, lineColor: Int = accent
    ) {
        var pts = if (o.chartMode == "stylized") stylizedPoints(t) else realPoints(t)
        if (pts.size == 1) pts = listOf(pts[0], Pt(1f, pts[0].y, null))
        if (pts.size < 2) return

        val minY = pts.minOf { it.y }
        val maxY = pts.maxOf { it.y }
        val rangeY = max(maxY - minY, maxY * 0.04f).coerceAtLeast(1f)
        val padY = 34f
        val ph = area.height() - padY * 2
        fun mapX(x: Float) = area.left + x * area.width()
        fun mapY(y: Float) = area.bottom - padY - ((y - minY) / rangeY) * ph

        // smooth the line (Catmull-Rom → bezier)
        val xs = pts.map { mapX(it.x) }
        val ys = pts.map { mapY(it.y) }
        val path = Path()
        path.moveTo(xs[0], ys[0])
        val tension = 0.5f
        for (i in 0 until pts.size - 1) {
            val p0x = xs[max(0, i - 1)]; val p0y = ys[max(0, i - 1)]
            val p1x = xs[i]; val p1y = ys[i]
            val p2x = xs[i + 1]; val p2y = ys[i + 1]
            val p3x = xs[min(pts.size - 1, i + 2)]; val p3y = ys[min(pts.size - 1, i + 2)]
            val c1x = p1x + (p2x - p0x) / 6f * tension * 2f
            val c1y = p1y + (p2y - p0y) / 6f * tension * 2f
            val c2x = p2x - (p3x - p1x) / 6f * tension * 2f
            val c2y = p2y - (p3y - p1y) / 6f * tension * 2f
            path.cubicTo(c1x, c1y, c2x, c2y, p2x, p2y)
        }

        // faint guide lines
        if (guides) {
            val guide = Paint().apply { color = Theme.alpha(text, 16); strokeWidth = 2f }
            for (i in 0..2) {
                val gy = area.top + padY + ph * i / 2f
                c.drawLine(area.left, gy, area.right, gy, guide)
            }
        }

        // clip to progress so the line "draws itself"
        val drawX = area.left + (area.width() + 8f) * easeOut(progress)
        c.save()
        c.clipRect(area.left - 20f, area.top - 20f, drawX, area.bottom + 20f)

        // area fill under the line
        val fillPath = Path(path)
        fillPath.lineTo(xs.last(), area.bottom)
        fillPath.lineTo(xs.first(), area.bottom)
        fillPath.close()
        val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, area.top, 0f, area.bottom,
                Theme.alpha(lineColor, 60), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }
        c.drawPath(fillPath, fp)

        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = lineW * 2.8f; color = Theme.alpha(lineColor, 40)
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, glow)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = lineW; color = lineColor
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, line)
        c.restore()

        // glowing head of the line (follows the drawing, stays on the exit when finished)
        if (tip) {
            val pm = android.graphics.PathMeasure(path, false)
            val len = pm.length
            if (len > 1f) {
                val pos = FloatArray(2)
                var best = 0f
                val steps = 160
                for (k in 0..steps) {
                    val d = len * k / steps
                    pm.getPosTan(d, pos, null)
                    if (pos[0] <= drawX) best = d else break
                }
                pm.getPosTan(best, pos, null)
                val tx = pos[0]
                val ty = pos[1]
                c.drawCircle(tx, ty, lineW * 6.5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(lineColor, 38) })
                c.drawCircle(tx, ty, lineW * 3.6f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(lineColor, 90) })
                c.drawCircle(tx, ty, lineW * 1.7f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            }
        }

        // markers on the real buys / sells (only once the line reaches them)
        if (o.markerStyle != "none") {
            val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 22f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            for (i in pts.indices) {
                val side = pts[i].side ?: continue
                if (xs[i] > drawX) continue
                val isBuy = side == "BUY"
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (isBuy) text else resultColor }
                val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
                c.drawCircle(xs[i], ys[i], 11f, ring)
                c.drawCircle(xs[i], ys[i], 7f, dot)
                if (o.markerStyle == "pill") {
                    val label = if (isBuy) "BUY" else "SELL"
                    val w = labelP.measureText(label) + 28f
                    val above = !(i > 0 && ys[i] < ys[i - 1] - 8f) // keep labels away from the line
                    val top = if (above) ys[i] - 58f else ys[i] + 22f
                    var left = xs[i] - w / 2f
                    left = left.coerceIn(area.left - 10f, area.right - w + 10f)
                    val r = RectF(left, top, left + w, top + 34f)
                    c.drawRoundRect(r, 17f, 17f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = text })
                    labelP.color = Theme.onColor(text)
                    c.drawText(label, r.centerX(), r.bottom - 9f, labelP)
                }
            }
        }
    }
}
