package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Everything the user can customize on a PnL card. Saved so the next card reopens in the same style. */
class CardOptions {
    var aspect: String = "4:5"          // "1:1" | "4:5" | "9:16"
    var bgStyle: String = "chrome"      // "black" | "chrome" | "coin" | "image"
    var darkness: Int = 35              // 0..95 (dark overlay over image / coin backgrounds)
    var heroMode: String = "sol"        // "sol" | "pct" | "multiple"
    var shader: String = "chrome"       // "clean" | "chrome" | "gold" | "green"
    var chartMode: String = "real"      // "real" (your actual fills) | "stylized" (decorative path)
    var markerStyle: String = "pill"    // "pill" | "dot" | "none"
    var showChart: Boolean = true
    var showCoin: Boolean = true
    var showStats: Boolean = true
    var showCa: Boolean = true
    var showBrand: Boolean = true
    var showPaperTag: Boolean = true
    var showGrain: Boolean = true
    var showVignette: Boolean = true
    var showFrame: Boolean = true
    var displayName: String = "73MCT"
    var handle: String = ""
    var bgHex: String = "#000000"
    var textHex: String = "#E6E8EB"
    var accentHex: String = "#C9CDD3"
    var profitHex: String = "#E6E8EB"
    var lossHex: String = "#8B8F96"

    fun load(p: SharedPreferences) {
        aspect = p.getString("aspect", aspect) ?: aspect
        bgStyle = p.getString("bgStyle", bgStyle) ?: bgStyle
        darkness = p.getInt("darkness", darkness)
        heroMode = p.getString("heroMode", heroMode) ?: heroMode
        shader = p.getString("shader", shader) ?: shader
        chartMode = p.getString("chartMode", chartMode) ?: chartMode
        markerStyle = p.getString("markerStyle", markerStyle) ?: markerStyle
        showChart = p.getBoolean("showChart", showChart)
        showCoin = p.getBoolean("showCoin", showCoin)
        showStats = p.getBoolean("showStats", showStats)
        showCa = p.getBoolean("showCa", showCa)
        showBrand = p.getBoolean("showBrand", showBrand)
        showPaperTag = p.getBoolean("showPaperTag", showPaperTag)
        showGrain = p.getBoolean("showGrain", showGrain)
        showVignette = p.getBoolean("showVignette", showVignette)
        showFrame = p.getBoolean("showFrame", showFrame)
        displayName = p.getString("displayName", displayName) ?: displayName
        handle = p.getString("handle", handle) ?: handle
        bgHex = p.getString("bgHex", bgHex) ?: bgHex
        textHex = p.getString("textHex", textHex) ?: textHex
        accentHex = p.getString("accentHex", accentHex) ?: accentHex
        profitHex = p.getString("profitHex", profitHex) ?: profitHex
        lossHex = p.getString("lossHex", lossHex) ?: lossHex
    }

    fun save(p: SharedPreferences) {
        p.edit()
            .putString("aspect", aspect).putString("bgStyle", bgStyle).putInt("darkness", darkness)
            .putString("heroMode", heroMode).putString("shader", shader).putString("chartMode", chartMode)
            .putString("markerStyle", markerStyle)
            .putBoolean("showChart", showChart).putBoolean("showCoin", showCoin)
            .putBoolean("showStats", showStats).putBoolean("showCa", showCa)
            .putBoolean("showBrand", showBrand).putBoolean("showPaperTag", showPaperTag)
            .putBoolean("showGrain", showGrain).putBoolean("showVignette", showVignette)
            .putBoolean("showFrame", showFrame)
            .putString("displayName", displayName).putString("handle", handle)
            .putString("bgHex", bgHex).putString("textHex", textHex).putString("accentHex", accentHex)
            .putString("profitHex", profitHex).putString("lossHex", lossHex)
            .apply()
    }

    companion object {
        const val PREFS = "pocketflip_card"
        fun open(context: Context): CardOptions {
            val o = CardOptions()
            o.load(context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE))
            return o
        }
    }
}

/**
 * Draws a PnL card for one finished meme-coin trade.
 * The layout is designed on a 1080-wide canvas and scaled to whatever bitmap size you ask for,
 * so the small live preview and the full-size export look identical.
 * [progress] 0..1 drives the count-up and the chart drawing (1 = finished card).
 */
object CardRenderer {

    const val BASE_W = 1080f

    fun heightFor(aspect: String, width: Int): Int = when (aspect) {
        "1:1" -> width
        "9:16" -> (width * 16f / 9f).toInt()
        else -> (width * 1.25f).toInt()
    }

    private fun col(hex: String, fallback: Int): Int = Theme.parseHex(hex) ?: fallback

    private fun easeOut(t: Float): Float {
        val x = 1f - t.coerceIn(0f, 1f)
        return 1f - x * x * x
    }

    fun render(
        t: ClosedTradeLog,
        o: CardOptions,
        coin: Bitmap?,
        bgImage: Bitmap?,
        emblem: Bitmap?,
        outWidth: Int,
        progress: Float = 1f
    ): Bitmap {
        val outH = heightFor(o.aspect, outWidth)
        val bmp = Bitmap.createBitmap(outWidth, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sc = outWidth / BASE_W
        c.scale(sc, sc)
        val W = BASE_W
        val H = outH / sc
        
        val bg = col(o.bgHex, Color.BLACK)
        val text = col(o.textHex, Color.WHITE)
        val accent = col(o.accentHex, Color.LTGRAY)
        val profit = col(o.profitHex, Color.WHITE)
        val loss = col(o.lossHex, Color.GRAY)
        val win = t.pnlSol >= 0.0
        val resultColor = if (win) profit else loss
        val muted = Theme.alpha(text, 140)

        drawBackground(c, W, H, o, bg, accent, coin, bgImage)

        if (o.showFrame) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2f
                color = Theme.alpha(text, 38)
            }
            c.drawRoundRect(RectF(26f, 26f, W - 26f, H - 26f), 44f, 44f, p)
        }

        val pad = 72f
        val prog = easeOut(progress)

        // ---------------- Header: emblem + name / handle, paper tag ----------------
        val headerY = 96f
        if (o.showBrand) {
            var tx = pad
            if (emblem != null) {
                val size = 64f
                val ep = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN) }
                c.drawBitmap(emblem, null, RectF(pad, headerY - 44f, pad + size, headerY + 20f), ep)
                tx = pad + size + 16f
            }
            val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 34f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                letterSpacing = 0.12f
            }
            c.drawText(o.displayName.ifBlank { "73MCT" }, tx, headerY - 4f, name)
            if (o.handle.isNotBlank()) {
                val h = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 24f; typeface = Typeface.DEFAULT }
                c.drawText(o.handle, tx, headerY + 24f, h)
            }
        }
        if (o.showPaperTag) {
            val label = "PAPER TRADE"
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 22f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                letterSpacing = 0.14f
            }
            val tw = tp.measureText(label)
            val r = RectF(W - pad - tw - 36f, headerY - 36f, W - pad, headerY + 6f)
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 2f; color = Theme.alpha(text, 110)
            }
            c.drawRoundRect(r, 21f, 21f, stroke)
            c.drawText(label, r.left + 18f, r.bottom - 12f, tp)
        }

        // ---------------- Coin row ----------------
        val coinY = when (o.aspect) { "1:1" -> 200f; "9:16" -> 360f; else -> 270f }
        var nameX = pad
        if (o.showCoin) {
            val r = 62f
            val cx = pad + r
            val cy = coinY
            drawCoin(c, coin, cx, cy, r, t, text, bg, accent)
            nameX = pad + r * 2 + 24f
        }
        val sym = if (t.symbol.startsWith("$")) t.symbol else "$" + t.symbol
        val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = text; textSize = 50f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val nm = ellipsize(t.name, nameP, W - nameX - pad)
        c.drawText(nm, nameX, coinY - 6f, nameP)
        val symP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textSize = 34f; typeface = Typeface.MONOSPACE
        }
        c.drawText(sym, nameX, coinY + 40f, symP)

        // ---------------- Hero number ----------------
        val heroY = when (o.aspect) { "1:1" -> 400f; "9:16" -> 760f; else -> 550f }
        val sign = if (win) "+" else "-"
        val heroText: String
        val heroUnit: String
        when (o.heroMode) {
            "pct" -> {
                heroText = String.format(Locale.US, "%s%.1f%%", sign, abs(t.roiPct) * prog)
                heroUnit = "RETURN ON INVESTED SOL"
            }
            "multiple" -> {
                val mult = 1.0 + (t.returnX - 1.0) * prog
                heroText = String.format(Locale.US, "%.2fx", max(0.0, mult))
                heroUnit = "RETURN MULTIPLE"
            }
            else -> {
                heroText = String.format(Locale.US, "%s%.3f", sign, abs(t.pnlSol) * prog)
                heroUnit = "SOL NET PNL"
            }
        }
        val heroP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 170f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            letterSpacing = -0.03f
        }
        val hw = heroP.measureText(heroText)
        if (hw > W - pad * 2) heroP.textSize = heroP.textSize * (W - pad * 2) / hw
        applyHeroShader(heroP, o.shader, resultColor, text, W, heroY)
        c.drawText(heroText, W / 2f, heroY, heroP)

        val unitP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 26f; textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); letterSpacing = 0.16f
        }
        c.drawText(heroUnit, W / 2f, heroY + 48f, unitP)

        // pills: ROI + multiple
        val pillY = heroY + 108f
        val pillText1 = Formatters.pctSigned1(t.roiPct)
        val pillText2 = Formatters.multX(t.returnX)
        drawPill(c, W / 2f - 12f, pillY, pillText1, resultColor, bg, true)
        drawPill(c, W / 2f + 12f, pillY, pillText2, text, bg, false)

        // ---------------- Chart ----------------
        val rowH = if (o.aspect == "1:1") 92f else 108f
        val statsTop = H - 202f - rowH
        val chartTop = pillY + 60f
        var chartBottom = statsTop - 40f
        if (!o.showStats) chartBottom = H - 190f
        if (o.showChart && chartBottom - chartTop > 120f) {
            drawChart(c, t, o, RectF(pad, chartTop, W - pad, chartBottom), accent, resultColor, text, bg, progress)
        }

        // ---------------- Stats ----------------
        if (o.showStats) {
            val items = listOf(
                "INVESTED" to Formatters.solPlain(t.solIn),
                "RETURNED" to Formatters.solPlain(t.solOut),
                "ENTRY MC" to Formatters.compactUsd(t.entryMc),
                "EXIT MC" to Formatters.compactUsd(t.avgExitMc),
                "PEAK MC" to Formatters.compactUsd(t.peakMc),
                "HELD" to Formatters.duration(t.holdDurationMs)
            )
            val colW = (W - pad * 2) / 3f
            val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = muted; textSize = 21f; letterSpacing = 0.12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = 35f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            val sep = Paint().apply { color = Theme.alpha(text, 26); strokeWidth = 2f }
            c.drawLine(pad, statsTop - 14f, W - pad, statsTop - 14f, sep)
            for ((i, item) in items.withIndex()) {
                val col = i % 3
                val row = i / 3
                val x = pad + col * colW
                val y = statsTop + 30f + row * rowH
                c.drawText(item.first, x, y, lab)
                val vp = Paint(valP)
                val maxW = colW - 16f
                val w = vp.measureText(item.second)
                if (w > maxW) vp.textSize = vp.textSize * maxW / w
                c.drawText(item.second, x, y + 44f, vp)
            }
        }

        // ---------------- Footer ----------------
        val foot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 22f; typeface = Typeface.MONOSPACE
        }
        val footY = H - 58f
        if (o.showCa) {
            c.drawText("CA  " + Formatters.shortCa(t.ca), pad, footY, foot)
        }
        foot.textAlign = Paint.Align.RIGHT
        c.drawText(Formatters.dateTime(t.closedAtMs), W - pad, footY, foot)

        // ---------------- Overlays ----------------
        if (o.showVignette) {
            val p = Paint().apply {
                shader = RadialGradient(
                    W / 2f, H / 2f, max(W, H) * 0.78f,
                    intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(150, 0, 0, 0)),
                    floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, W, H, p)
        }
        if (o.showGrain) {
            val rnd = Random(73)
            val gp = Paint().apply { strokeWidth = 2f }
            val count = (W * H / 220f).toInt()
            for (i in 0 until count) {
                val a = rnd.nextInt(26)
                gp.color = if (rnd.nextBoolean()) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
                c.drawPoint(rnd.nextFloat() * W, rnd.nextFloat() * H, gp)
            }
        }
        return bmp
    }

    // ------------------------------------------------------------------

    private fun ellipsize(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 1 && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    private fun drawBackground(
        c: Canvas, W: Float, H: Float, o: CardOptions, bg: Int, accent: Int,
        coin: Bitmap?, bgImage: Bitmap?
    ) {
        val fill = Paint().apply { color = bg }
        c.drawRect(0f, 0f, W, H, fill)
        val dark = (o.darkness.coerceIn(0, 95) / 100f * 255).toInt()
        when (o.bgStyle) {
            "chrome" -> {
                val glow = Paint().apply {
                    shader = RadialGradient(
                        W * 0.5f, H * 0.08f, W * 0.95f,
                        intArrayOf(Theme.alpha(accent, 70), Theme.alpha(accent, 18), Color.TRANSPARENT),
                        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                    )
                }
                c.drawRect(0f, 0f, W, H, glow)
                val glow2 = Paint().apply {
                    shader = RadialGradient(
                        W * 0.95f, H * 1.02f, W * 0.8f,
                        intArrayOf(Theme.alpha(accent, 38), Color.TRANSPARENT),
                        floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
                    )
                }
                c.drawRect(0f, 0f, W, H, glow2)
            }
            "coin" -> if (coin != null) {
                drawCover(c, blur(coin), W, H)
                c.drawRect(0f, 0f, W, H, Paint().apply { color = Color.argb(max(dark, 120), 0, 0, 0) })
            }
            "image" -> if (bgImage != null) {
                drawCover(c, bgImage, W, H)
                c.drawRect(0f, 0f, W, H, Paint().apply { color = Color.argb(dark, 0, 0, 0) })
            }
            else -> {}
        }
    }

    /** Cheap blur: shrink a lot, scale back up with smoothing. */
    private fun blur(src: Bitmap): Bitmap {
        val small = Bitmap.createScaledBitmap(src, max(8, src.width / 24), max(8, src.height / 24), true)
        return Bitmap.createScaledBitmap(small, 256, 256, true)
    }

    private fun drawCover(c: Canvas, b: Bitmap, W: Float, H: Float) {
        val s = max(W / b.width, H / b.height)
        val w = b.width * s
        val h = b.height * s
        val l = (W - w) / 2f
        val tp = (H - h) / 2f
        c.drawBitmap(b, null, RectF(l, tp, l + w, tp + h), Paint(Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawCoin(c: Canvas, coin: Bitmap?, cx: Float, cy: Float, r: Float, t: ClosedTradeLog, text: Int, bg: Int, accent: Int) {
        if (coin != null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val shader = BitmapShader(coin, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val m = android.graphics.Matrix()
            val s = (r * 2f) / min(coin.width, coin.height)
            m.postTranslate(-coin.width / 2f, -coin.height / 2f)
            m.postScale(s, s)
            m.postTranslate(cx, cy)
            shader.setLocalMatrix(m)
            p.shader = shader
            c.drawCircle(cx, cy, r, p)
        } else {
            // Letter placeholder so the card never has an empty hole.
            val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.alpha(text, 34) }
            c.drawCircle(cx, cy, r, fillP)
            val letter = t.symbol.trimStart('$').take(1).uppercase().ifEmpty { "?" }
            val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = text; textSize = r * 1.1f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
            c.drawText(letter, cx, cy + r * 0.38f, lp)
        }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = Theme.alpha(accent, 150)
        }
        c.drawCircle(cx, cy, r + 3f, ring)
    }

    private fun applyHeroShader(p: Paint, style: String, resultColor: Int, text: Int, W: Float, baseY: Float) {
        val top = baseY - 150f
        when (style) {
            "chrome" -> p.shader = LinearGradient(
                0f, top, 0f, baseY,
                intArrayOf(Color.parseColor("#FFFFFF"), Color.parseColor("#C9CDD3"), Color.parseColor("#6E727A"), Color.parseColor("#E8EAED")),
                floatArrayOf(0f, 0.45f, 0.62f, 1f), Shader.TileMode.CLAMP
            )
            "gold" -> p.shader = LinearGradient(
                0f, top, 0f, baseY,
                intArrayOf(Color.parseColor("#FFF3B0"), Color.parseColor("#E8B923"), Color.parseColor("#8A5A00"), Color.parseColor("#F7D154")),
                floatArrayOf(0f, 0.45f, 0.65f, 1f), Shader.TileMode.CLAMP
            )
            "green" -> p.shader = LinearGradient(
                0f, top, 0f, baseY,
                intArrayOf(Color.parseColor("#B8FFD6"), Color.parseColor("#22C55E"), Color.parseColor("#0B7A3B")),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            else -> p.color = if (resultColor == text) text else resultColor
        }
    }

    private fun drawPill(c: Canvas, anchorX: Float, y: Float, label: String, color: Int, bg: Int, rightAligned: Boolean) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = 36f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val tw = tp.measureText(label)
        val w = tw + 56f
        val left = if (rightAligned) anchorX - w else anchorX
        val r = RectF(left, y - 38f, left + w, y + 22f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Theme.alpha(color, 30) }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; this.color = Theme.alpha(color, 120)
        }
        c.drawRoundRect(r, 30f, 30f, fill)
        c.drawRoundRect(r, 30f, 30f, stroke)
        c.drawText(label, r.left + 28f, r.bottom - 15f, tp)
    }

    // ------------------------------------------------------------------
    // Chart
    // ------------------------------------------------------------------

    private data class Pt(val x: Float, val y: Float, val side: String?)

    /** Market cap path built from the trade's real fills (and the peak, so you can see what you left behind). */
    private fun realPoints(t: ClosedTradeLog): List<Pt> {
        val fills = t.fills.sortedBy { it.timeMs }
        if (fills.isEmpty()) return emptyList()
        val t0 = fills.first().timeMs
        val span = max(1L, fills.last().timeMs - t0).toFloat()
        val raw = fills.map { Triple((it.timeMs - t0) / span, it.mc.toFloat(), it.side) }
        return raw.map { Pt(it.first, it.second, it.third) }
    }

    /** Decorative path from entry to peak to exit. Same start, peak and end as the trade; the wiggles between are invented. */
    private fun stylizedPoints(t: ClosedTradeLog): List<Pt> {
        val rnd = Random(t.id.hashCode().toLong())
        val entry = t.entryMc.toFloat()
        val exit = t.avgExitMc.toFloat()
        val peak = max(t.peakMc.toFloat(), max(entry, exit))
        val n = 24
        val peakAt = 0.62f
        val out = ArrayList<Pt>()
        for (i in 0 until n) {
            val x = i / (n - 1f)
            val base = if (x <= peakAt) {
                val k = x / peakAt
                entry + (peak - entry) * (k * k * (3f - 2f * k))
            } else {
                val k = (x - peakAt) / (1f - peakAt)
                peak + (exit - peak) * (k * k * (3f - 2f * k))
            }
            val amp = (peak - min(entry, exit)).coerceAtLeast(entry * 0.05f) * 0.07f
            val noise = if (i == 0 || i == n - 1) 0f else (rnd.nextFloat() - 0.5f) * 2f * amp
            val side = when (i) { 0 -> "BUY"; n - 1 -> "SELL"; else -> null }
            out.add(Pt(x, max(base + noise, entry * 0.2f), side))
        }
        return out
    }

    private fun drawChart(
        c: Canvas, t: ClosedTradeLog, o: CardOptions, area: RectF,
        accent: Int, resultColor: Int, text: Int, bg: Int, progress: Float
    ) {
        var pts = if (o.chartMode == "stylized") stylizedPoints(t) else realPoints(t)
        if (pts.size == 1) pts = listOf(pts[0], Pt(1f, pts[0].y, null))
        if (pts.size < 2) return

        val minY = pts.minOf { it.y }
        val maxY = pts.maxOf { it.y }
        val rangeY = max(maxY - minY, maxY * 0.04f).coerceAtLeast(1f)
        val padY = 34f
        val ph = area.height() - padY * 2
        fun mapX(x: Float) = area.left + x * area.width()
        fun mapY(y: Float) = area.bottom - padY - ((y - minY) / rangeY) * ph

        // smooth the line (Catmull-Rom → bezier)
        val xs = pts.map { mapX(it.x) }
        val ys = pts.map { mapY(it.y) }
        val path = Path()
        path.moveTo(xs[0], ys[0])
        val tension = 0.5f
        for (i in 0 until pts.size - 1) {
            val p0x = xs[max(0, i - 1)]; val p0y = ys[max(0, i - 1)]
            val p1x = xs[i]; val p1y = ys[i]
            val p2x = xs[i + 1]; val p2y = ys[i + 1]
            val p3x = xs[min(pts.size - 1, i + 2)]; val p3y = ys[min(pts.size - 1, i + 2)]
            val c1x = p1x + (p2x - p0x) / 6f * tension * 2f
            val c1y = p1y + (p2y - p0y) / 6f * tension * 2f
            val c2x = p2x - (p3x - p1x) / 6f * tension * 2f
            val c2y = p2y - (p3y - p1y) / 6f * tension * 2f
            path.cubicTo(c1x, c1y, c2x, c2y, p2x, p2y)
        }

        // faint guide lines
        val guide = Paint().apply { color = Theme.alpha(text, 16); strokeWidth = 2f }
        for (i in 0..2) {
            val gy = area.top + padY + ph * i / 2f
            c.drawLine(area.left, gy, area.right, gy, guide)
        }

        // clip to progress so the line "draws itself"
        val drawX = area.left + (area.width() + 8f) * easeOut(progress)
        c.save()
        c.clipRect(area.left - 20f, area.top - 20f, drawX, area.bottom + 20f)

        // area fill under the line
        val fillPath = Path(path)
        fillPath.lineTo(xs.last(), area.bottom)
        fillPath.lineTo(xs.first(), area.bottom)
        fillPath.close()
        val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, area.top, 0f, area.bottom,
                Theme.alpha(accent, 60), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }
        c.drawPath(fillPath, fp)

        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 14f; color = Theme.alpha(accent, 40)
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, glow)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 5f; color = accent
            strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        c.drawPath(path, line)
        c.restore()

        // markers on the real buys / sells (only once the line reaches them)
        if (o.markerStyle != "none") {
            val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 22f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            for (i in pts.indices) {
                val side = pts[i].side ?: continue
                if (xs[i] > drawX) continue
                val isBuy = side == "BUY"
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (isBuy) text else resultColor }
                val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
                c.drawCircle(xs[i], ys[i], 11f, ring)
                c.drawCircle(xs[i], ys[i], 7f, dot)
                if (o.markerStyle == "pill") {
                    val label = if (isBuy) "BUY" else "SELL"
                    val w = labelP.measureText(label) + 28f
                    val above = !(i > 0 && ys[i] < ys[i - 1] - 8f) // keep labels away from the line
                    val top = if (above) ys[i] - 58f else ys[i] + 22f
                    var left = xs[i] - w / 2f
                    left = left.coerceIn(area.left - 10f, area.right - w + 10f)
                    val r = RectF(left, top, left + w, top + 34f)
                    c.drawRoundRect(r, 17f, 17f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = text })
                    labelP.color = Theme.onColor(text)
                    c.drawText(label, r.centerX(), r.bottom - 9f, labelP)
                }
            }
        }
    }
}
